
//
//  CommenDefine.h
//  MasonryText
//
//  Created by Sunweisheng on 2018/8/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#ifndef CommenDefine_h
#define CommenDefine_h

#define SCREENWIDTH [UIScreen mainScreen].bounds.size.width
#define SCREENHEIGHT [UIScreen mainScreen].bounds.size.height

#define setDefault(str, key) [[NSUserDefaults standardUserDefaults] setObject:str forKey:key]
#define gainDefault(key) [[NSUserDefaults standardUserDefaults] valueForKey:key]

#define rgb(x, y, z) [UIColor colorWithRed:x green:y blue:z alpha:1]

#define Image(x, y) [UIImage imageWithContentsOfFile:[[NSBundle mainBundle]pathForResource:x ofType:y]]

#define WSColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#endif /* CommenDefine_h */
