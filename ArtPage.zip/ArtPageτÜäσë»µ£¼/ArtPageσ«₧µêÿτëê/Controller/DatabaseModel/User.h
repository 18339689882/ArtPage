//
//  User.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/2.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (nonatomic, strong)NSString *UserID;
@property (nonatomic, strong)NSString *ACCOUNT_DOMAIN;
@property (nonatomic, strong)NSString *ACCOUNT_TYPE2;
@property (nonatomic, strong)NSString *endDate;

@end
