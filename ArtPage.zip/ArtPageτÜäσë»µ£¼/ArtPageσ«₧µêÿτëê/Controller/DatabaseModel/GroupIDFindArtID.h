//
//  GroupIDFindArtID.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/27.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroupIDFindArtID : NSObject

@property (nonatomic, strong) NSString *GroupID;
@property (nonatomic, strong) NSString *ArtWorkID;

@end
