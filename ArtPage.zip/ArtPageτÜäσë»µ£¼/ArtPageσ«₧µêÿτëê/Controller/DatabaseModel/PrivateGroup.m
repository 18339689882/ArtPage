//
//  PrivateGroup.m
//  ArtPage
//
//  Created by Sunweisheng on 2018/9/22.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PrivateGroup.h"

@implementation PrivateGroup

@end
