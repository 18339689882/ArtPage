//
//  Login.h
//  ArtPage
//
//  Created by Sunweisheng on 2018/9/20.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Login : NSObject

@property (nonatomic, strong)NSString *ACCOUNT_DOMAIN;
@property (nonatomic, strong)NSString *ACCOUNT_TYPE2;
@property (nonatomic, strong)NSString *UserID;
@property (nonatomic, strong)NSString *endDate;

@end
