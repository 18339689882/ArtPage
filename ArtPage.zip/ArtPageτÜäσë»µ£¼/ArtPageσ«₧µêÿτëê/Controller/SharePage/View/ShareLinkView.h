//
//  ShareLinkView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/1.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareLinkView : UIView

@property (nonatomic, strong)UILabel *shareLinkLab;
@property (nonatomic, strong)UILabel *urlLab;

@property (nonatomic, strong)UIImageView *lineView;

@end
