//
//  ShareLinkView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/1.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ShareLinkView.h"

@implementation ShareLinkView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        //分享链接label
        _shareLinkLab = [[UILabel alloc] init];
        _shareLinkLab.textAlignment = NSTextAlignmentCenter;
        _shareLinkLab.textColor = WSColorFromRGB(0xa0a0a0);
        _shareLinkLab.text = @"分享链接";
        [_shareLinkLab setFont:[UIFont fontWithName:@"Helvetica_Bold" size:14]];
        [self addSubview:_shareLinkLab];
        [_shareLinkLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.centerX);
            make.top.equalTo(0);
            make.width.equalTo(80);
            make.height.equalTo(20);
        }];
        //url
        _urlLab = [[UILabel alloc] init];
        _urlLab.textAlignment = NSTextAlignmentCenter;
        _urlLab.font = [UIFont systemFontOfSize:14];
        _urlLab.textColor = WSColorFromRGB(0x626262);
        _urlLab.text = @"http://artist.artp.cc/123/artlist";
        [self addSubview:_urlLab];
        [_urlLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.centerX);
            make.top.equalTo(self.shareLinkLab.bottom).offset(40);
            make.width.equalTo(SCREENWIDTH - 130);
            make.height.equalTo(15);
        }];
        //底部线
        for(int i = 0; i < 2; ++i)
        {
            _lineView = [[UIImageView alloc] init];
            _lineView.backgroundColor = [UIColor grayColor];
            [self addSubview:_lineView];
            [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.shareLinkLab.bottom).offset(20 + 50 * i);
                make.left.equalTo(0);
                make.width.equalTo(SCREENWIDTH);
                make.height.equalTo(0.8);
            }];
        }
    }
    return  self;
}

@end
