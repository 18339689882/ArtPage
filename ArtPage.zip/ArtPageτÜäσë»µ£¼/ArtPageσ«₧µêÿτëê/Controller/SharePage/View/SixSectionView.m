//
//  SixSectionView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//
#pragma mark -- 这里你要写6个block在控制器中  分别响应不同的操作
#import "SixSectionView.h"

@implementation SixSectionView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        //复制链接按钮
        _copLinkBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_copLinkBtn addTarget:self action:@selector(pressFirstBtn) forControlEvents:UIControlEventTouchUpInside];
        [self setLeftButton:_copLinkBtn andPhoName:@"btn_复制链接" andBottom:-120 andLeft:50];
        //微信好友按钮
        _weiChatBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_weiChatBtn addTarget:self action:@selector(pressSecondBtn) forControlEvents:UIControlEventTouchUpInside];
        [self setMiddleButton:_weiChatBtn andPhoName:@"btn_微信好友" andBottom:-120];
        //朋友圈按钮
        _friendCycleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_friendCycleBtn addTarget:self action:@selector(pressThirdBtn) forControlEvents:UIControlEventTouchUpInside];
        [self setRightButton:_friendCycleBtn andPhoName:@"btn_朋友圈" andBottom:-120 andRight:-50];
        //新浪微博按钮
        _sinaBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_sinaBtn addTarget:self action:@selector(pressFourBtn) forControlEvents:UIControlEventTouchUpInside];
        [self setLeftButton:_sinaBtn andPhoName:@"btn_新浪微博" andBottom:-40 andLeft:50];
        //信息按钮
        _messageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_messageBtn addTarget:self action:@selector(pressFiveBtn) forControlEvents:UIControlEventTouchUpInside];
        [self setMiddleButton:_messageBtn andPhoName:@"btn_信息" andBottom:-40];
        //邮件按钮
        _emailBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_emailBtn addTarget:self action:@selector(pressSixBtn) forControlEvents:UIControlEventTouchUpInside];
        [self setRightButton:_emailBtn andPhoName:@"btn_邮件" andBottom:-40 andRight:-50];
    }
    return self;
}
#pragma mark -- 不同机型怎么解决。。
//左按钮
-(void)setLeftButton:(UIButton *)btn andPhoName:(NSString *)phoName andBottom:(int)bottom andLeft:(int)left
{
    [btn setImage:[UIImage imageNamed:phoName] forState:UIControlStateNormal];
    [self addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(bottom);
        make.left.equalTo(left);
        make.width.height.equalTo(65);
    }];
}
//中按钮
-(void)setMiddleButton:(UIButton *)btn andPhoName:(NSString *)phoName andBottom:(int)bottom
{
    [btn setImage:[UIImage imageNamed:phoName] forState:UIControlStateNormal];
    [self addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(bottom);
        make.centerX.equalTo(self.centerX);
        make.width.height.equalTo(65);
    }];
}
//右按钮
-(void)setRightButton:(UIButton *)btn andPhoName:(NSString *)phoName andBottom:(int)bottom andRight:(int)right
{
    [btn setImage:[UIImage imageNamed:phoName] forState:UIControlStateNormal];
    [self addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(bottom);
        make.right.equalTo(right);
        make.width.height.equalTo(65);
    }];
}
//点击第一个按钮
-(void)pressFirstBtn
{
    if(_firstBlock)
    {
        _firstBlock(self);
    }
}
//点击第二个btn
-(void)pressSecondBtn
{
    if(_secondBlock)
    {
        _secondBlock(self);
    }
}

-(void)pressThirdBtn
{
    if(_thirdBlock)
    {
        _thirdBlock(self);
    }
}
-(void)pressFourBtn
{
    if(_fourBlock)
    {
        _fourBlock(self);
    }
}
-(void)pressFiveBtn
{
    if(_fiveBlock)
    {
        _fiveBlock(self);
    }
}
-(void)pressSixBtn
{
    if(self.emailBtn.selected)
    {
        self.emailBtn.selected = NO;
    }
    else
    {
        self.emailBtn.selected = YES;
    }
    if(_sixBlock)
    {
        _sixBlock(self);
    }
}
@end
