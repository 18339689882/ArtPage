//
//  SixSectionView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SixSectionView : UIView

@property (nonatomic, strong)UIButton *copLinkBtn;
@property (nonatomic, strong)UIButton *weiChatBtn;
@property (nonatomic, strong)UIButton *friendCycleBtn;
@property (nonatomic, strong)UIButton *sinaBtn;
@property (nonatomic, strong)UIButton *messageBtn;
@property (nonatomic, strong)UIButton *emailBtn;

//block块
typedef void(^Block)(SixSectionView *firstBlock);
@property (nonatomic, strong)Block firstBlock;
@property (nonatomic, strong)Block secondBlock;
@property (nonatomic, strong)Block thirdBlock;
@property (nonatomic, strong)Block fourBlock;
@property (nonatomic, strong)Block fiveBlock;
@property (nonatomic, strong)Block sixBlock;

@end
