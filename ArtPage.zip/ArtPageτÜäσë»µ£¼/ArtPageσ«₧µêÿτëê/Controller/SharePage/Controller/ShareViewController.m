//
//  ShareViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ShareViewController.h"
#import "SixSectionView.h"
#import "ShareLinkView.h"
#import "WXApi.h"
@interface ShareViewController ()

@property (nonatomic, strong)SixSectionView *shareSixView;
@property (nonatomic, strong)ShareLinkView *shareLinkView;
@end

#define kLoadImage(name, type) [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:name ofType:type]]

@implementation ShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setLeftLogo:YES];
    [self setTabbar:NO andClose:YES];
    [self initSixShareView];
    [self initShareLinkView];
}

-(void)initShareLinkView
{
    _shareLinkView = [[ShareLinkView alloc] initWithFrame:CGRectMake(0, 200, SCREENWIDTH, 100)];
    [self.view addSubview:_shareLinkView];
}
-(void)initSixShareView
{
    _shareSixView = [[SixSectionView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT - 260, SCREENWIDTH, 200)];
    _shareSixView.firstBlock = ^(SixSectionView *firstBlock) {
        NSLog(@"你点击了第一个按钮");
        
        //复制文本  此处应该是弹窗.
        UIPasteboard *pab = [UIPasteboard generalPasteboard];
        NSString *string = @"123456";
        [pab setString:string];
        if (pab == nil) {
            NSLog(@"复制失败");
        }else
        {
            NSLog(@"复制成功");
        }
    };
    _shareSixView.secondBlock = ^(SixSectionView *firstBlock) {
        NSLog(@"你点击了微信好友");
        WXMediaMessage *message = [WXMediaMessage message];
        message.title = @"华杉科技";
        message.description = @"在高薪和经验的路上，我们只做行业第一";
        [message setThumbImage:kLoadImage(@"share", @"png")];
        
        WXWebpageObject *ext = [WXWebpageObject object];
        ext.webpageUrl = @"http://www.huashankeji.com";
        message.mediaObject = ext;
        
        SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
        req.bText = NO;
        req.message = message;
        //这个属性表示分享到好友
        req.scene = WXSceneSession;
        [WXApi sendReq:req];
    };
    _shareSixView.thirdBlock = ^(SixSectionView *firstBlock) {
        NSLog(@"你点击了朋友圈");
        //这种分享是带文字和图片的分享，属于网页分享，注意分享的图片大小不能超过32k。
        WXMediaMessage *message = [WXMediaMessage message];
        message.title = @"华杉科技";
        message.description = @"在高薪和经验的路上，我们只做行业第一";
        [message setThumbImage:kLoadImage(@"share", @"png")];
        
        WXWebpageObject *ext = [WXWebpageObject object];
        ext.webpageUrl = @"http://www.huashankeji.com";
        message.mediaObject = ext;
        
        SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
        req.bText = NO;
        req.message = message;
        //这个属性表示分享到朋友圈
        req.scene = WXSceneTimeline;
        [WXApi sendReq:req];
        
        //这种分享的是纯文字的信息。
        //SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
        //req.text = @"http://www.huashankeji.com";
        //req.bText = YES;
        //req.scene = WXSceneSession;
        //[WXApi sendReq:req];
        
    };
    _shareSixView.fourBlock = ^(SixSectionView *firstBlock) {
        NSLog(@"你点击了第四个按钮");
    };
    _shareSixView.fiveBlock = ^(SixSectionView *firstBlock) {
        NSLog(@"你点击了第五个按钮");
    };
    _shareSixView.sixBlock = ^(SixSectionView *firstBlock) {
        NSLog(@"你点击了第六个按钮");
    };
    [self.view addSubview:_shareSixView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
