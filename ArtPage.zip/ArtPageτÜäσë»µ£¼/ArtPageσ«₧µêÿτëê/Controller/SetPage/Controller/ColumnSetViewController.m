//
//  ColumnSetViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/3.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ColumnSetViewController.h"
#import "ColumnSetView.h"
#import "ColumnView.h"
@interface ColumnSetViewController ()
{
    int i;
}
@property (nonatomic,strong) ColumnSetView *columnSetView;

@end

@implementation ColumnSetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //显示logo
    [self setLeftLogo:YES];
    //显示关闭按钮
    [self setTabbar:NO andClose:YES];
    [self initColumnSetView];
}
//初始化页面
-(void)initColumnSetView
{
    _columnSetView = [[ColumnSetView alloc] initWithFrame:CGRectMake(0, 90, SCREENWIDTH, SCREENHEIGHT - 150)];
    [self.view addSubview:_columnSetView];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
