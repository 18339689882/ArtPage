//
//  SetViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "SetViewController.h"
#import "SixSectionView.h"
#import "PersonInformationView.h"
#import "LoginViewController.h"
#import "ColumnSetViewController.h"
#import "AboutArtPageViewController.h"
#import "DownloadViewController.h"
@interface SetViewController ()

@property (nonatomic, strong)SixSectionView *setSixView;
@property (nonatomic, strong)PersonInformationView *personView;

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //显示关闭按钮
    [self setTabbar:NO andClose:YES];
    //显示logo
    [self setLeftLogo:YES];
    //初始化设置按钮
    [self initSetBtnView];
    //初始化个人信息
    [self initPersonInformation];
}
-(void)initSetBtnView
{
    _setSixView = [[SixSectionView alloc] initWithFrame:CGRectMake(0, 315, SCREENWIDTH, 168)];
    [_setSixView.copLinkBtn setImage:[UIImage imageNamed:@"btn_同步数据"] forState:UIControlStateNormal];
    
    __weak typeof(self) weakSelf = self;
    _setSixView.firstBlock = ^(SixSectionView *firstBlock) {
        //获取当前时间。
        [weakSelf setCurrentDate];
    
        [weakSelf.navigationController pushViewController:[[DownloadViewController alloc] init] animated:YES];
    };
    [_setSixView.weiChatBtn setImage:[UIImage imageNamed:@"btn_变更账户"] forState:UIControlStateNormal];
    _setSixView.secondBlock = ^(SixSectionView *firstBlock) {

        [weakSelf.navigationController pushViewController:[[LoginViewController alloc] init] animated:YES];
    };
    [_setSixView.friendCycleBtn setImage:[UIImage imageNamed:@"btn_栏目设定"] forState:UIControlStateNormal];
    _setSixView.thirdBlock = ^(SixSectionView *firstBlock) {
        [weakSelf.navigationController pushViewController:[[ColumnSetViewController alloc] init] animated:YES];
    };
    [_setSixView.sinaBtn setImage:[UIImage imageNamed:@"btn_访问网页版"] forState:UIControlStateNormal];
    _setSixView.fourBlock = ^(SixSectionView *firstBlock) {
        [weakSelf interWebView];
    };
    [_setSixView.emailBtn setImage:[UIImage imageNamed:@"btn_关于ArtPage"] forState:UIControlStateNormal];
    _setSixView.sixBlock = ^(SixSectionView *firstBlock) {
        [weakSelf.navigationController pushViewController:[[AboutArtPageViewController alloc] init] animated:YES];
    };
    _setSixView.messageBtn.hidden = YES;
    [self.view addSubview:_setSixView];
}
-(void)initPersonInformation
{
    _personView = [[PersonInformationView alloc] initWithFrame:CGRectMake(0, 80, SCREENWIDTH, 180)];
    [self.view addSubview:_personView];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//设置当前时间
-(void)setCurrentDate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    NSDate *dateNow = [NSDate date];
    self.dateString = [formatter stringFromDate:dateNow];
    setDefault(self.dateString, @"dateString");
//    NSLog(@"currentTime = %@", self.dateString);
}
//进入网页版
-(void)interWebView
{
    NSString *urlstr = @"https://www.baidu.com";
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlstr]];
}
@end
