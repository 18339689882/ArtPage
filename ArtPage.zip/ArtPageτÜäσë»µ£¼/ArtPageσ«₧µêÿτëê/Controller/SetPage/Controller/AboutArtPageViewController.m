//
//  AboutArtPageViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/3.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "AboutArtPageViewController.h"
#import "AboutArtPageView.h"
@interface AboutArtPageViewController ()

@property (nonatomic,strong) AboutArtPageView *aboutAPView;

@end

@implementation AboutArtPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //显示logo
    [self setLeftLogo:YES];
    //关闭按钮
    [self setTabbar:NO andClose:YES];
    //初始化View
    [self initAboutArtPageView];
}

-(void)initAboutArtPageView
{
    _aboutAPView = [[AboutArtPageView alloc] initWithFrame:CGRectMake(0, 90, SCREENWIDTH, SCREENHEIGHT - 150)];
    [self.view addSubview:_aboutAPView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
