//
//  AboutArtPageViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/3.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PublicViewController.h"

@interface AboutArtPageViewController : PublicViewController

@end
