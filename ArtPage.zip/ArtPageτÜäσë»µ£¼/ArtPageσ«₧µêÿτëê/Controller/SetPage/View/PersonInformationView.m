//
//  PersonInformationView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/2.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PersonInformationView.h"

@implementation PersonInformationView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        NSArray *arr = [NSArray arrayWithObjects:@"当前用户:", @"个性域名:", @"账户类型:", @"账户有效期:", @"上一次同步时间:", nil];
        for(int i = 0; i < 5; ++i)
        {
            _pubLab = [[UILabel alloc] init];
            [self setPubLable:_pubLab andText:arr[i] andTop:i];
        }
        for(int j = 0; j < 2; ++j)
        {
            _lineView = [[UIImageView alloc] init];
            _lineView.backgroundColor = [UIColor grayColor];
            [self addSubview:_lineView];
            [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(20 + 150 * j);
                make.left.equalTo(0);
                make.width.equalTo(SCREENWIDTH);
                make.height.equalTo(0.5);
            }];
        }
       //后半部分
        _nameLab = [[UILabel alloc] init];
        //切换中英文
        NSString *nameStr;
        nameStr = [[[GetDataBase shareDataBase] wzGainTableRecoderID:@"About"][0] valueForKey:@"ARTIST_NAME_CN"];
        if([gainDefault(@"charType") isEqualToString:@"english"])
            nameStr = [[[GetDataBase shareDataBase] wzGainTableRecoderID:@"About"][0] valueForKey:@"ARTIST_NAME_EN"];
        [self setLab:_nameLab andText:nameStr andLeft:90 andTop:40];
        
        _domain = [[UILabel alloc] init];
        NSString *domainStr = [NSString stringWithFormat:@"%@.artp.cc", gainDefault(@"ACCOUNT_DOMAIN")];
        [self setLab:_domain andText:domainStr andLeft:90 andTop:65];
        
        _accountType = [[UILabel alloc] init];
        NSString *acountText = nil;
        int type = [gainDefault(@"ACCOUNT_TYPE2") intValue];
        if(type == 1)
        {
            acountText = @"个人用户";
        }
        else
        {
            acountText = @"机构用户";
        }
        [self setLab:_accountType andText:acountText andLeft:90 andTop:90];
        
        _validity = [[UILabel alloc] init];
        [self setLab:_validity andText:gainDefault(@"endDate") andLeft:105 andTop:115];
        
        _lastSyncDat = [[UILabel alloc] init];
        [self setLab:_lastSyncDat andText:gainDefault(@"dateString") andLeft:125 andTop:140];
    }
    return self;
}
//前部分label函数
-(void)setPubLable:(UILabel *)lab andText:(NSString *)text andTop:(int)top
{
    lab.text = text;
    [lab setFont:[UIFont fontWithName:@"Helvetica_Bold" size:12]];
    lab.font = [UIFont systemFontOfSize:12];
    lab.textColor = [UIColor grayColor];
    lab.textAlignment = NSTextAlignmentLeft;
    [self addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(30);
        make.top.equalTo(25 * top + 40);
        make.width.equalTo(170);
        make.height.equalTo(15);
    }];
}
//后部分label函数
-(void)setLab:(UILabel *)label andText:(NSString *)text andLeft:(int)left andTop:(int)top
{
    label.textColor = [UIColor grayColor];
    [label setFont:[UIFont fontWithName:@"Helvetica_Bold" size:12]];
    label.font = [UIFont systemFontOfSize:12];
    label.text = text;
    [self addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(top);
        make.left.equalTo(left);
        make.width.equalTo(180);
        make.height.equalTo(15);
    }];
}

@end
