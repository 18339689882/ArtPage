//
//  AboutArtPageView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/4.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//
//  *********没有约束看你怎么弄**************//
//  测试线是不是被盖住了  哼哼。
#import "AboutArtPageView.h"

@implementation AboutArtPageView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _labArr = [NSArray arrayWithObjects:@"当前版本号1.0", @"介绍", @"ArtPage，让作品展示与商业合作更加简单。", @"iPhone版ArtPage，可“一键式同步”用户在Web端的数据，以便使用者在离线状态也能够浏览作品与履历。", @"意见反馈", @"邮箱：vip@artp.cc", @"QQ:2757388400", @"网址：http://www.artp.cc", nil];
        for (int i = 0; i < 8; ++i)
        {
            _pubLab = [[UILabel alloc] init];
            switch (i) {
                case 0:
                {
                    [self setLineImgView:0];
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:20 andHeight:20];
                    [self setLineImgView:60];
                }
                    break;
                case 1:
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:80 andHeight:20];
                    break;
                case 2:
                {
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:110 andHeight:60];
                    _pubLab.numberOfLines = 0;
                }
                    break;
                case 3:
                {
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:160 andHeight:100];
                    NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc] initWithString:_pubLab.text];
                    NSMutableParagraphStyle *paragtaphSty = [[NSMutableParagraphStyle alloc] init];
                    [paragtaphSty setLineSpacing:10];
                    [attributedStr addAttribute:NSParagraphStyleAttributeName value:paragtaphSty range:NSMakeRange(0, [_pubLab.text length])];
                    _pubLab.attributedText = attributedStr;
                    _pubLab.lineBreakMode = NSLineBreakByCharWrapping;
                    _pubLab.numberOfLines = 3;
                    [self setLineImgView:270];
                }
                    break;
                case 4:
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:290 andHeight:20];
                    break;
                case 5:
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:320 andHeight:20];
                    break;
                case 6:
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:350 andHeight:20];
                    break;
                case 7:
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:380 andHeight:20];
                    break;
                case 8:
                {
                    [self setAboutLab:_pubLab andText:_labArr[i] andTop:430 andHeight:20];
                }
                    break;
                default:
                    break;
            }
        }
    }
    return self;
}

-(void)setAboutLab:(UILabel *)lab andText:(NSString *)text andTop:(int)top andHeight:(int)height
{
    lab.textColor = WSColorFromRGB(0xa0a0a0);
    lab.font = [UIFont systemFontOfSize:12];
    [lab setFont:[UIFont fontWithName:@"Helvetica_Bold" size:12]];
    lab.text = text;
    lab.textAlignment = NSTextAlignmentLeft;
    [self addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(10);
        make.top.equalTo(top);
        make.width.equalTo(SCREENWIDTH - 20);
        make.height.equalTo(height);
    }];
}
-(void)setLineImgView:(int)top
{
    _lineView = [[UIImageView alloc] init];
    _lineView.backgroundColor = [UIColor grayColor];
    [self addSubview:_lineView];
    [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(top);
        make.left.equalTo(0);
        make.width.equalTo(SCREENWIDTH);
        make.height.equalTo(0.8);
    }];
}
@end
