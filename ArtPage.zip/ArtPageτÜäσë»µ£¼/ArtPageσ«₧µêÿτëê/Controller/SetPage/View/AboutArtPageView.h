//
//  AboutArtPageView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/4.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutArtPageView : UIView

@property (nonatomic,strong) UILabel *pubLab;
@property (nonatomic,strong) NSArray *labArr;
@property (nonatomic,strong) UIImageView *lineView;

@end
