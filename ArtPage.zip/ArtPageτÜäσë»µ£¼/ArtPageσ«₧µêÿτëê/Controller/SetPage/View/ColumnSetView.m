//
//  ColumnSetView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/3.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ColumnSetView.h"

@implementation ColumnSetView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        for (int i = 0; i < 2; ++i)
        {
            _lineView = [[UIImageView alloc] init];
            _lineView.backgroundColor = [UIColor grayColor];
            [self addSubview:_lineView];
            [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(0 + 108 * i);
                make.left.equalTo(0);
                make.width.equalTo(SCREENWIDTH);
                make.height.equalTo(0.5);
            }];
        }
        
        _contentLabel = [[UILabel alloc] init];
        _contentLabel.font = [UIFont systemFontOfSize:13];
        _contentLabel.textColor = [UIColor grayColor];
        _contentLabel.text = @"栏目设定 | 在这里，您可以暂时的停用导航中的某些栏目，以应对不同的展示需求。停用后栏目内容不会被删除。";
        UIFont *boldFont = [UIFont boldSystemFontOfSize:16];
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:_contentLabel.text];
        [attStr addAttribute:NSFontAttributeName value:boldFont range:[_contentLabel.text rangeOfString:@"栏目设定"]];
        _contentLabel.attributedText = attStr;
        _contentLabel.numberOfLines = 3;
        [self addSubview:_contentLabel];
        [_contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.equalTo(20);
            make.width.equalTo(SCREENWIDTH - 40);
            make.height.equalTo(70);
        }];
        for(int i = 0; i < 4; ++i)
        {
            NSArray *titleArr = [NSArray arrayWithObjects:@"公开作品",@"非公开作品",@"日志",@"关于", nil];
            NSArray *imgArr = [NSArray arrayWithObjects:@"btn_公开作品x", @"btn_非公开作品x", @"btn_日志x", @"btn_关于x", nil];
            _iconImgView = [[UIImageView alloc] init];
            _iconImgView.image = [UIImage imageNamed:imgArr[i]];
            [self addSubview:_iconImgView];
            [_iconImgView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.contentLabel.bottom).offset(28 + 53 * i);
                make.left.equalTo(20);
                make.width.equalTo(40);
                make.height.equalTo(40);
            }];
            
            _titleLab = [[UILabel alloc] init];
            _titleLab.text = titleArr[i];
            _titleLab.textColor = WSColorFromRGB(0xa0a0a0);
            _titleLab.font = [UIFont systemFontOfSize:13];
            [self addSubview:_titleLab];
            [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.contentLabel.bottom).offset(40 + 53 * i);
                make.left.equalTo(self.iconImgView.right).offset(8);
                make.width.equalTo(100);
                make.height.equalTo(16);
            }];
            
            _lineView = [[UIImageView alloc] init];
            _lineView.backgroundColor = [UIColor grayColor];
            [self addSubview:_lineView];
            [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.titleLab.bottom).offset(20);
                make.left.equalTo(0);
                make.width.equalTo(SCREENWIDTH);
                make.height.equalTo(0.8);
            }];
        }
        //右边button
        _pubBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_pubBtn addTarget:self action:@selector(pressPubBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self setColumnButton:_pubBtn andTop:0 andBtnStr:@"pubBtn"];
        
        _noPubBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_noPubBtn addTarget:self action:@selector(pressNopubBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self setColumnButton:_noPubBtn andTop:53 * 1 andBtnStr:@"noPubBtn"];
        
        _diaryBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_diaryBtn addTarget:self action:@selector(pressDiaryBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self setColumnButton:_diaryBtn andTop:53 * 2 andBtnStr:@"diaryBtn"];
        
        _aboutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_aboutBtn addTarget:self action:@selector(pressAboutBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self setColumnButton:_aboutBtn andTop:53 * 3 andBtnStr:@"aboutBtn"];
    }
    return self;
}

-(void)setColumnButton:(UIButton *)btn andTop:(int)t andBtnStr:(NSString *)btnStr
{
    if([gainDefault(btnStr) isEqualToString:@"1"])
    {
        btn.selected = NO;
    }
    else
    {
        btn.selected = YES;
    }
    [btn setImage:[UIImage imageNamed:@"开-1"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"关-1"] forState:UIControlStateSelected];
    [self addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.bottom).offset(40 + t);//53
        make.right.equalTo(-20);
        make.width.equalTo(50);
        make.height.equalTo(25);
    }];
}

-(void)pressPubBtn:(UIButton *)btn
{
    if(btn.selected)
    {
        btn.selected = NO;
        setDefault(@"1", @"pubBtn");
    }
    else
    {
        setDefault(@"0", @"pubBtn");
        btn.selected = YES;
    }
}

-(void)pressNopubBtn:(UIButton *)btn
{
    if(btn.selected)
    {
        btn.selected = NO;
        setDefault(@"1", @"noPubBtn");
    }
    else
    {
        setDefault(@"0", @"noPubBtn");
        btn.selected = YES;
    }
}

-(void)pressDiaryBtn:(UIButton *)btn
{
    if(btn.selected)
    {
        btn.selected = NO;
        setDefault(@"1", @"diaryBtn");
    }
    else
    {
        setDefault(@"0", @"diaryBtn");
        btn.selected = YES;
    }
}
-(void)pressAboutBtn:(UIButton *)btn
{
    if(btn.selected)
    {
        btn.selected = NO;
        setDefault(@"1", @"aboutBtn");
    }
    else
    {
        setDefault(@"0", @"aboutBtn");
        btn.selected = YES;
    }
}
@end
