//
//  PersonInformationView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/2.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface PersonInformationView : UIView

@property (nonatomic, strong)UILabel *pubLab;
@property (nonatomic, strong)UIImageView *lineView;

@property (nonatomic, strong)UILabel *nameLab;
@property (nonatomic, strong)UILabel *domain;
@property (nonatomic, strong)UILabel *accountType;
@property (nonatomic, strong)UILabel *validity;
@property (nonatomic, strong)UILabel *lastSyncDat;

@end
