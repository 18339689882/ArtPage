//
//  ColumnSetView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/3.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColumnSetView : UIView
{
    int tag;
}
@property (nonatomic, strong)UILabel *contentLabel;
@property (nonatomic, strong)UIImageView *lineView;
@property (nonatomic, strong)UIImageView *iconImgView;
@property (nonatomic, strong)UILabel *titleLab;

@property (nonatomic, strong)UIButton *pubBtn;
@property (nonatomic, strong)UIButton *noPubBtn;
@property (nonatomic, strong)UIButton *diaryBtn;
@property (nonatomic, strong)UIButton *aboutBtn;

typedef void(^ColumnSetBlock)(ColumnSetView *block, NSInteger tag);
@property (nonatomic,copy)ColumnSetBlock myBlock;

@property (nonatomic,strong) UIButton *btn;
@end
