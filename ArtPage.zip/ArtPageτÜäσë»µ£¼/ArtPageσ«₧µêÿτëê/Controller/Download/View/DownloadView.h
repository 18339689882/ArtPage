//
//  DownloadView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFOwnerHTTPSessionManager.h"
@interface DownloadView : UIView
@property (nonatomic, strong)UIImageView *logoImgView;
@property (nonatomic, strong)UILabel *contentLabel;

@property (nonatomic, strong)UIButton *backBtn;
@property (nonatomic, strong)UILabel *persentLable;

typedef void(^backBlock)(DownloadView *block);
@property (nonatomic, strong)backBlock block;


@end
