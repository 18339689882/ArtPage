//
//  DownloadView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "DownloadView.h"

@implementation DownloadView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        _contentLabel = [[UILabel alloc] init];
        _contentLabel.textColor = [UIColor grayColor];
        _contentLabel.text = @"数据同步 | 执行该步骤将会下载您在ArtPage上的全部图片和相关数据，200张图片的下载容量约为20M，建议在WIFI环境下使用该功能，以免产生额外的流量费用。";
        UIFont *boldFont = [UIFont boldSystemFontOfSize:18.0];
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:_contentLabel.text];
        [attStr addAttribute:NSFontAttributeName value:boldFont range:[_contentLabel.text rangeOfString:@"数据同步"]];//设置Text这四个字母的字体为粗体
        _contentLabel.attributedText = attStr;
        _contentLabel.numberOfLines = 6;
        [self addSubview:_contentLabel];
        [_contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(110);
            make.left.equalTo(20);
            make.right.equalTo(-20);
            make.height.equalTo(150);
            make.width.equalTo(SCREENWIDTH - 40);
        }];
        
        //百分数label
        _persentLable = [[UILabel alloc] init];
        _persentLable.textAlignment = NSTextAlignmentRight;
        _persentLable.textColor = [UIColor grayColor];
        _persentLable.text = @"0%";
        [_persentLable setFont:[UIFont systemFontOfSize:35.0]];
        [self addSubview:_persentLable];
        [_persentLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-10);
            make.bottom.equalTo(-20);
            make.width.equalTo(100);
            make.height.equalTo(40);
        }];
        
        //返回按钮
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backBtn setImage:[UIImage imageNamed:@"btn_返回"] forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(backMethod) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_backBtn];
        [_backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(-20);
            make.left.equalTo(17);
            make.height.equalTo(37);
            make.width.equalTo(22);
        }];
    }
    return self;
}
//返回按钮
-(void)backMethod
{
    if(_block)
    {
        _block(self);
    }
}
@end
