//
//  DownloadViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PublicViewController.h"

@interface DownloadViewController : PublicViewController
{
    dispatch_queue_t queue;
}

//存放GroupID
@property (nonatomic, strong)NSMutableArray *GroupIDArr;
@property (nonatomic, strong)NSMutableArray *priGroupArr;
@property (nonatomic, strong)UIButton *downloadBtn;

@end
