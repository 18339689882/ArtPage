//
//  DownloadViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "DownloadViewController.h"
#import "DownloadView.h"
#import "GroupIDFindArtID.h"
#import "IndexTableViewController.h"
#import "CommonClass.h"
@interface DownloadViewController ()

@property (nonatomic, strong)DownloadView *downloadView;

@property (nonatomic, strong) NSString *str1;
@property (nonatomic, strong) NSString *str2;
//下载个数。
@property (nonatomic, assign) NSInteger downloadCount;
//点击button次数
@property (nonatomic, assign) NSInteger clickCount;

@end

@implementation DownloadViewController

-(NSMutableArray *)GroupIDArr
{
    if(!_GroupIDArr)
    {
        _GroupIDArr = [[NSMutableArray alloc] init];
    }
    return _GroupIDArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //logo
    [self setLeftLogo:YES];
    //初始化自定义视图
    [self initDownloadView];
    
}

-(void) initDownloadView
{
    _clickCount = 0;
    _downloadView = [[DownloadView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT)];
    [self.view addSubview:_downloadView];
    //下载按钮
    _downloadBtn = [[UIButton alloc] init];
    [_downloadBtn setTitle:@"开始下载" forState:UIControlStateNormal];
    [_downloadBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    _downloadBtn.backgroundColor = [UIColor blackColor];
    _downloadBtn.layer.masksToBounds = YES;
    _downloadBtn.layer.cornerRadius = 6.0;
    _downloadBtn.layer.borderWidth = 1.5;
    _downloadBtn.tag = 0;
    _downloadBtn.layer.borderColor = [[UIColor grayColor] CGColor];
    [_downloadBtn addTarget:self action:@selector(clickDownloadBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_downloadBtn];
    [_downloadBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.downloadView.contentLabel.bottom).offset(40);
        make.centerX.equalTo(self.view.centerX);
        make.width.equalTo(SCREENWIDTH - 100);
        make.height.equalTo(60);
    }];
    //返回上一个登录界面
    __weak typeof(self) weakSelf = self;
    _downloadView.block = ^(DownloadView *block) {
        [weakSelf.navigationController popViewControllerAnimated:YES];
    };
}
-(void)clickDownloadBtn
{
    _clickCount ++;
    if(_clickCount == 1)
    {
        [self downloadPhoto];
        [_downloadBtn setTitle:@"暂停下载" forState:UIControlStateNormal];
        self.downloadView.backBtn.hidden = YES;
    }
    else if(_clickCount % 2 == 0)
    {
        [[AFOwnerHTTPSessionManager shareManager] suspendAllDownload];
        [_downloadBtn setTitle:@"继续下载" forState:UIControlStateNormal];
    }
    else{
        [_downloadBtn setTitle:@"暂停下载" forState:UIControlStateNormal];
        [[AFOwnerHTTPSessionManager shareManager] startAllDownload];
    }
}
-(void)downloadOver
{
    [self.navigationController pushViewController:[[IndexTableViewController alloc] init] animated:YES];
}
-(void)downloadPhoto
{
    //显示正在加载中
    [CommonClass showMBProgressHUD:@"正在加载中" andWhereView:self.navigationController.view];
    
#pragma -- 获取所有公开分组
    queue = dispatch_queue_create("MyQueue", DISPATCH_QUEUE_CONCURRENT);
    __weak typeof(self) weakSelf = self;
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        //创建信号量
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        manager.completionQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);//不写会线程阻塞。
        [manager GET:[NSString stringWithFormat:@"http://www.artp.cc/pages/jsonService/jsonForIPad.aspx?Method=GetPublicGroup&UserID=%@", gainDefault(@"UserID")] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //NSLog(@"%@", responseObject);
            //转型
            NSDictionary *dic = (NSDictionary *)responseObject;
            NSArray *array = dic[@"data"];
            //从接口获取成功的字典中得到GroupID
            [weakSelf.GroupIDArr addObjectsFromArray:[array valueForKey:@"GroupID"]];
            //NSLog(@"%@", weakSelf.GroupIDArr);
            for(int i = 0; i < array.count; ++i)
            {
                //判断数据库中是否存在GroupID。
                if(![[GetDataBase shareDataBase] isExistTable:@"PublicGroup" andObject:[[responseObject objectForKey:@"data"] objectAtIndex:i] andObjectAtIndex:0])
                {
                    //写入数据库
                    [[GetDataBase shareDataBase] insertRecorderDataWithTableName:@"PublicGroup" andModel:[[responseObject objectForKey:@"data"] objectAtIndex:i]];
                }
            }
            //信号通知
            dispatch_semaphore_signal(semaphore);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@", error);
            dispatch_semaphore_signal(semaphore);
        }];
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);

#pragma --获得所有加密分组
        manager = [AFHTTPSessionManager manager];
        //创建信号量
        dispatch_semaphore_t privateSemaphore = dispatch_semaphore_create(0);
        manager.completionQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);//不写会线程阻塞。
        [manager GET:[NSString stringWithFormat:@"http://www.artp.cc/pages/jsonService/jsonForIPad.aspx?Method=GetECPGroup&UserID=%@", gainDefault(@"UserID")] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //NSLog(@"%@", responseObject);
            //转型
            NSDictionary *dic = (NSDictionary *)responseObject;
            NSArray *array = dic[@"data"];
            //从接口获取成功的字典中得到GroupID
            NSArray *priGroupArr = [array valueForKey:@"GroupID"];
            //NSLog(@"%@", priGroupArr);
            
            [weakSelf.GroupIDArr addObjectsFromArray:priGroupArr];
            //NSLog(@"%@", weakSelf.GroupIDArr);
            
            for(int i = 0; i < array.count; ++i)
            {
                //判断数据库中是否存在GroupID。
                if(![[GetDataBase shareDataBase] isExistTable:@"PrivateGroup" andObject:[[responseObject objectForKey:@"data"] objectAtIndex:i] andObjectAtIndex:0])
                {
                    //写入数据库
                    [[GetDataBase shareDataBase] insertRecorderDataWithTableName:@"PrivateGroup" andModel:[[responseObject objectForKey:@"data"] objectAtIndex:i]];
                }
            }
            //信号通知
            dispatch_semaphore_signal(privateSemaphore);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@", error);
            dispatch_semaphore_signal(privateSemaphore);
        }];
        dispatch_semaphore_wait(privateSemaphore, DISPATCH_TIME_FOREVER);
    
#pragma -- 获取公开和私密分组内的所有图片
        manager = [AFHTTPSessionManager manager];
        manager.completionQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_semaphore_t allSemaphore = dispatch_semaphore_create(0);
        for(int i = 0; i < weakSelf.GroupIDArr.count; ++i)
        {
            [manager GET:[NSString stringWithFormat:@"http://www.artp.cc/pages/jsonService/jsonForIPad.aspx?Method=GetArtWorksByGroup&GroupID=%@", weakSelf.GroupIDArr[i]] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"%@", responseObject);
                //转型
                NSDictionary *dic = (NSDictionary *)responseObject;
                NSArray *array = dic[@"data"];
                
                //新建一个表格，把GroupID 和 ArtID对应存入。
                for(int j = 0; j < array.count; ++j)
                {
                    GroupIDFindArtID *ID = [[GroupIDFindArtID alloc] init];
                    ID.GroupID = self.GroupIDArr[i];
                    ID.ArtWorkID = [[array valueForKey:@"ArtWorkID"] objectAtIndex:j];
                    if(![[GetDataBase shareDataBase] isExistTable:@"GroupIDFindArtID" andObject:ID andObjectAtIndex:1])
                    {
                        [[GetDataBase shareDataBase] insertRecorderDataWithTableName:@"GroupIDFindArtID" andModel:ID];
                    }
                    //NSLog(@"GroupID %@", self.GroupIDArr[i]);
                    //NSLog(@"ArtWorkID %@", [[array valueForKey:@"ArtWorkID"] objectAtIndex:j]);
                }
                //判断数据库中是否已经存在数据
                for(int i = 0; i < array.count; ++i)
                {
                    if(![[GetDataBase shareDataBase] isExistTable:@"GroupPhoto" andObject:[[responseObject objectForKey:@"data"] objectAtIndex:i] andObjectAtIndex:0])
                    {
                        //写入数据库
                        [[GetDataBase shareDataBase] insertRecorderDataWithTableName:@"GroupPhoto" andModel:[[responseObject objectForKey:@"data"] objectAtIndex:i]];
                    }
                }
                //信号通知
                dispatch_semaphore_signal(allSemaphore);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@", error);
                dispatch_semaphore_signal(allSemaphore);
            }];
            dispatch_semaphore_wait(allSemaphore, DISPATCH_TIME_FOREVER);
        }
    
#pragma --获取日志
    [self setbarrier_async:@"http://www.artp.cc/pages/jsonService/jsonForIPad.aspx?Method=GetNewsList&UserID=%@" andModelName:@"Diary"];
#pragma --获取关于
    [self setbarrier_async:@"http://www.artp.cc/pages/jsonService/jsonForIPad.aspx?Method=GetAbout&UserID=%@" andModelName:@"About"];
    
#pragma mark -------------下载groupImg--------------
    
#pragma mark -- 下载日志图片
    [self downLoadImg:@"Diary" andUrl:@"IMAGE_URL" andPath:@"%@/Library/Caches/%@/diaryPhoto" andImgName:@"diary%d.jpg"];
#pragma mark -- 下载关于图片
    [self downLoadImg:@"About" andUrl:@"ARTIST_IMAGE" andPath:@"%@/Library/Caches/%@/aboutPhoto" andImgName:@"about%d.jpg"];
#pragma mark -- 下载缩略图片
    [self downLoadPhoto:@"%@/Library/Caches/%@/THUMBNAILPhoto/%@" andTypeStr:@"ARTWORK_THUMBNAIL"];
#pragma mark -- 下载原图图片
    [self downLoadPhoto:@"%@/Library/Caches/%@/originPhoto/%@" andTypeStr:@"ARTWORK_FILE_ORIGINAL"];
}
//调用网络接口函数
-(void)setbarrier_async:(NSString *)netStr andModelName:(NSString *)nameStr
{
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        //创建信号量
        dispatch_semaphore_t semaphore1 = dispatch_semaphore_create(0);
        manager.completionQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);//不写会线程阻塞。
        [manager GET:[NSString stringWithFormat:netStr, gainDefault(@"UserID")] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //NSLog(@"%@", responseObject);
            //转型
            NSDictionary *dic = (NSDictionary *)responseObject;
            NSArray *array = dic[@"data"];
            for(int i = 0; i < array.count; ++i)
            {
                //判断数据库中是否存在GroupID。
                if(![[GetDataBase shareDataBase] isExistTable:nameStr andObject:[[responseObject objectForKey:@"data"] objectAtIndex:i] andObjectAtIndex:0])
                {
                    //写入数据库
                    [[GetDataBase shareDataBase] insertRecorderDataWithTableName:nameStr andModel:[[responseObject objectForKey:@"data"] objectAtIndex:i]];
                }
            }
            //信号通知
            dispatch_semaphore_signal(semaphore1);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@", error);
            dispatch_semaphore_signal(semaphore1);
        }];
        dispatch_semaphore_wait(semaphore1, DISPATCH_TIME_FOREVER);
}
//下载分组图片函数
//pathStr : 文件下载地址 typeStr 图片的类型。
-(void)downLoadPhoto:(NSString *)pathStr andTypeStr:(NSString *)typeStr
{
    dispatch_barrier_async(queue, ^{
        //获取所有图片数量
        long allPhotoCount = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"GroupPhoto"].count * 2 + [[GetDataBase shareDataBase] wzGainTableRecoderID:@"Diary"].count + [[GetDataBase shareDataBase] wzGainTableRecoderID:@"About"].count;
        NSLog(@"allPhotoCount = %ld",allPhotoCount);
        NSLog(@"%ld",self.GroupIDArr.count);
        for(int i = 0; i < self.GroupIDArr.count; ++i)
        {
            dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
            //不同的GroupID在originPhoto下创建不同的文件夹
            NSString *filePath = [NSString stringWithFormat:pathStr, NSHomeDirectory(), gainDefault(@"userName"), self.GroupIDArr[i]];
            NSFileManager *fileManager = [NSFileManager defaultManager];
            BOOL exits = [fileManager fileExistsAtPath:filePath];
            if(!exits)
            {
                [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
            }
            NSLog(@"%@", filePath);
            
            //从数据库中取出图片链接
            //1,从GroupIDFindArtID表中通过GroupID中得到ArtWorkID
            NSDictionary *dic = @{@"GroupID":self.GroupIDArr[i]};
            NSMutableArray *originPhotoArr = [[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupIDFindArtID" andDicitonary:dic];
            //NSLog(@"%@", [originPhotoArr[0] valueForKey:@"ArtWorkID"]);
            //图片名字设置为ArtWorkID
            NSMutableArray *fileName = [originPhotoArr valueForKey:@"ArtWorkID"];
            if(originPhotoArr.count)
            {
                for(int k = 0; k < originPhotoArr.count; ++k)
                {
                    //2，再从photoGroup表中通过ArtWorkID找到原始图片链接
                    NSDictionary *artIDDic = @{@"ArtWorkID":[originPhotoArr[k] valueForKey:@"ArtWorkID"]};
                    NSMutableArray *originUrlArr =  [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupPhoto" andDicitonary:artIDDic] valueForKey:typeStr];
                    //得到将要存储的图片的ArtWorkID
                    NSArray * phoNameArr = [[[GetDataBase shareDataBase] wzGainTableRecoderID:@"GroupPhoto"] valueForKey:@"ArtWorkID"];
                    BOOL photoExits = [fileManager fileExistsAtPath:[NSString stringWithFormat:@"%@/%@.jpg", filePath, phoNameArr[k]]];
                    //NSLog(@"%id", photoExits);//输出为l1 为yes
                    //NSLog(@"%ld", originPhotoArr.count);
                    //NSLog(@"%@", [NSString stringWithFormat:@"%@/%@.jpg", filePath, phoNameArr[k]]);
                    //判断本地是否存在图片
                    __weak typeof(self) weakSelf = self;
                    if(photoExits)
                    {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            self.downloadCount++;
                            //NSLog(@"%ld", self.downloadCount);
                            float count = (self.downloadCount * 1.0 / allPhotoCount * 100);
                            self.downloadView.persentLable.text = [NSString stringWithFormat:@"%.0lf%%", count];
                            if([self.downloadView.persentLable.text isEqual:@"100%"])
                            {
                                [self.downloadBtn setTitle:@"回到主页面" forState:UIControlStateNormal];
                                self.downloadView.contentLabel.text = @"数据同步完成 | 您在ArtPage上的全部图片与相关数据已同步到当前设备中。如需管理分组及作品，请使用浏览器访问网页端ArtPage。";
                                [weakSelf.downloadBtn addTarget:self action:@selector(downloadOver) forControlEvents:UIControlEventTouchUpInside];
                            }
                            NSLog(@"分组图片count= %lf, text is = %@", count, self.downloadView.persentLable.text);
                        });
                        dispatch_semaphore_signal(semaphore);
                    }
                    else
                    {
                        __weak typeof(self) weakSelf = self;
                        [[AFOwnerHTTPSessionManager shareManager] downloadFileURL:[NSString stringWithFormat:@"http://www.artp.cc/%@",originUrlArr[0]] filesavePath:filePath fileName:[NSString stringWithFormat:@"%@.jpg", fileName[k]] progress:^(NSProgress *downloadProgress) {
                            dispatch_semaphore_signal(semaphore);
                            //NSLog(@"%@", downloadProgress);
                        } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
                            self.downloadCount++;
                            float count = (self.downloadCount * 1.0 / allPhotoCount * 100);
                            self.downloadView.persentLable.text = [NSString stringWithFormat:@"%.0lf%%", count];
                            if([weakSelf.downloadView.persentLable.text isEqual:@"100%"])
                            {
                                [weakSelf.downloadBtn setTitle:@"回到主页面" forState:UIControlStateNormal];
                                self.downloadView.contentLabel.text = @"数据同步完成 | 您在ArtPage上的全部图片与相关数据已同步到当前设备中。如需管理分组及作品，请使用浏览器访问网页端ArtPage。";
                                [weakSelf.downloadBtn addTarget:self action:@selector(downloadOver) forControlEvents:UIControlEventTouchUpInside];
                            }
                            NSLog(@"分组图片count= %lf, text is = %@", count, self.downloadView.persentLable.text);
                            dispatch_semaphore_signal(semaphore);
                        }];
                    }
                }
                dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
            }
        }
    });
}
//下载日志和关于图片。
-(void)downLoadImg:(NSString *)tableName andUrl:(NSString *)Url andPath:(NSString *)path andImgName:(NSString *)imgName
{
    //隐藏转圈操作。
    [CommonClass hideMBprogressHUD:self.navigationController.view];
    
    dispatch_barrier_async(queue, ^{
        long allPhotoCount = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"GroupPhoto"].count * 2 + [[GetDataBase shareDataBase] wzGainTableRecoderID:@"Diary"].count + [[GetDataBase shareDataBase] wzGainTableRecoderID:@"About"].count;
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        //得到日志图片的链接
        NSMutableArray * diarMutArr = [[[GetDataBase shareDataBase] wzGainTableRecoderID:tableName] valueForKey:Url];
        //NSLog(@"%@", diarMutArr);
        //设置文件存储路径
        NSString *diaryPath = [NSString stringWithFormat:path, NSHomeDirectory(), gainDefault(@"userName")];
        NSFileManager * fileManager = [NSFileManager defaultManager];
        BOOL exits = [fileManager fileExistsAtPath:diaryPath];
        if(!exits)
        {
            [fileManager createDirectoryAtPath:diaryPath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        for(int i = 0; i < diarMutArr.count; ++i)
        {
            [[AFOwnerHTTPSessionManager shareManager] downloadFileURL:[NSString stringWithFormat:@"http://www.artp.cc/%@", diarMutArr[i]] filesavePath:diaryPath fileName:[NSString stringWithFormat:imgName, i] progress:^(NSProgress *downloadProgress) {
                //NSLog(@"%@",downloadProgress);
                dispatch_semaphore_signal(semaphore);
            } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
                self.downloadCount++;
                float count = (self.downloadCount * 1.0 / allPhotoCount * 100);
                self.downloadView.persentLable.text = [NSString stringWithFormat:@"%.0lf%%", count];
                self.downloadView.contentLabel.text = @"数据同步中 | 取消下载会暂时停止同步数据，下次同步时会继续从本次下载的进度开始同步。";
                NSLog(@"日志图片count= %lf, text is = %@", count, self.downloadView.persentLable.text);
                dispatch_semaphore_signal(semaphore);
            }];
        }
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    });
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //禁用右滑返回
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //恢复右滑返回
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
}
@end
