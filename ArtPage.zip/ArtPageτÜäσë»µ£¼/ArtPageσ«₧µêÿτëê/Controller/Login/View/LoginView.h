//
//  LoginView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginView : UIView

@property (nonatomic, strong)UIImageView *headImgView;
@property (nonatomic, strong)UITextField *userTextField;
@property (nonatomic, strong)UITextField *pwdTextField;
@property (nonatomic, strong)UIButton *loginBtn;
@property (nonatomic, strong)UIImageView *lineImgView;
@property (nonatomic, strong)UIImageView *clearImgView;

@property (nonatomic, strong) NSString *str1;
@property (nonatomic, strong) NSString *str2;

typedef void(^jumpBLock)(LoginView *block);
@property (nonatomic, copy)jumpBLock block;

-(void)setTextfiled:(UITextField *)textField andTop:(int)top andText:(NSString *)str;

@end
