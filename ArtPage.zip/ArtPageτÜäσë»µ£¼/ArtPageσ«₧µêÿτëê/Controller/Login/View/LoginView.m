//
//  LoginView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "LoginView.h"
@implementation LoginView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        //ArtPage图片
        _headImgView = [[UIImageView alloc] init];
        _headImgView.image = [UIImage imageNamed:@"img_首页Logo"];
        [self addSubview:_headImgView];
        [_headImgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(100);
            make.centerX.equalTo(self.centerX);
            make.width.equalTo(150);
            make.height.equalTo(60);
        }];
        //两条灰色线
        for(int i = 0; i < 2; ++i)
        {
            _lineImgView = [[UIImageView alloc] init];
            _lineImgView.backgroundColor = [UIColor grayColor];
            [self addSubview:_lineImgView];
            [_lineImgView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.headImgView.top).offset(i * 60 + 170);
                make.centerX.equalTo(self.centerX);
                make.height.equalTo(1);
                make.width.equalTo(SCREENWIDTH - 100);
            }];
        }
        //两个textfile
        _userTextField = [[UITextField alloc] init];
        self.userTextField.text = @"18339689882";
        [self setTextfiled:_userTextField andTop:120 andText:@"用户名"];
        _pwdTextField = [[UITextField alloc] init];
        _pwdTextField.secureTextEntry = YES;
        self.pwdTextField.text = @"123456";
        [self setTextfiled:_pwdTextField andTop:180 andText:@"密码"];
        //登录按钮
        _loginBtn = [[UIButton alloc] init];
        [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        [_loginBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        _loginBtn.backgroundColor = [UIColor blackColor];
        _loginBtn.layer.masksToBounds = YES;
        _loginBtn.layer.cornerRadius = 6.0;
        _loginBtn.layer.borderWidth = 1.5;
        _loginBtn.layer.borderColor = [[UIColor grayColor] CGColor];
        [_loginBtn addTarget:self action:@selector(pressLoginBtn) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_loginBtn];
        [_loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.pwdTextField.bottom).offset(10);
            make.centerX.equalTo(self.centerX);
            make.width.equalTo(SCREENWIDTH - 100);
            make.height.equalTo(60);
        }];
    }
    return self;
    
}

-(void)setTextfiled:(UITextField *)textField andTop:(int)top andText:(NSString *)str
{
    textField.textAlignment = NSTextAlignmentLeft;
    textField.textColor = [UIColor whiteColor];
    textField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor grayColor],NSForegroundColorAttributeName, nil]];
    [self addSubview:textField];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.headImgView.bottom).offset(top);
        make.left.equalTo(50);
        make.height.equalTo(60);
        make.width.equalTo(180);
    }];
}

-(void)pressLoginBtn
{
    __weak typeof (self) weakSelf = self;
    
    self.str1 = self.userTextField.text;
    self.str2 = self.pwdTextField.text;
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:[NSString stringWithFormat:@"http://www.artp.cc/pages/jsonService/jsonForIPad.aspx?Method=CheckUser&UserName=%@&Password=%@", weakSelf.str1, weakSelf.str2] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //NSLog(@"%@", responseObject);
        //转型
        NSDictionary *dic = (NSDictionary *)responseObject;
        NSArray *array = dic[@"data"];
        
        if([responseObject objectForKey:@"ErrMessage"] == [NSNull null])
        {
            setDefault([array[0] valueForKey:@"UserID"], @"UserID");
            setDefault([array[0] valueForKey:@"ACCOUNT_DOMAIN"], @"ACCOUNT_DOMAIN");
            setDefault([array[0] valueForKey:@"ACCOUNT_TYPE2"], @"ACCOUNT_TYPE2");
            setDefault([array[0] valueForKey:@"endDate"], @"endDate");
            setDefault(weakSelf.userTextField.text, @"userName");
            if(weakSelf.block)
            {
                weakSelf.block(self);
            }
        }
        else
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:[responseObject objectForKey:@"ErrMessage"] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alertView show];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"访问数据失败");
        NSLog(@"%@", error);
    }];
}
@end

