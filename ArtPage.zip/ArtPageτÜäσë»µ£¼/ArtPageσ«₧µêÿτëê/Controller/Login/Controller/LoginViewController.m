//
//  LoginViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "LoginViewController.h"
#import "DownloadViewController.h"
@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //第一次进入默认为中文
    setDefault(@"chinese",@"charType");
    NSLog(@"%@", gainDefault(@"charType"));
    [self initLoginView];
    [self addNotification];
}
#pragma --初始化登录界面
-(void)initLoginView
{    
    _loginView = [[LoginView alloc] init];
    [self.view addSubview:_loginView];
    [_loginView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(0);
        make.left.equalTo(0);
        make.width.equalTo(SCREENWIDTH);
        make.height.equalTo(SCREENHEIGHT);
    }];
    __weak typeof(self) weakSelf = self;
    _loginView.block = ^(LoginView *block) {
        [weakSelf.navigationController pushViewController:[[DownloadViewController alloc] init] animated:YES];
    };
}

#pragma make-- 添加观察者至通知者中心
-(void)addNotification
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBordShow:) name:UIKeyboardWillShowNotification object:nil];
}
-(void)keyBordShow:(NSNotification *)noti
{
    //获取键盘高度
    NSDictionary *userInfo = noti.userInfo;
    NSValue *keyboardValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = keyboardValue.CGRectValue;
    CGFloat keyboardHeight = keyboardRect.size.height;//键盘高度
    CGFloat viewHeight = _loginView.loginBtn.frame.origin.y + self.loginView.loginBtn.frame.size.height;//得到btn最低端的Y值
    //判断被遮挡时则使界面变化(键盘距离button按钮底部距离25)
    if(SCREENHEIGHT - keyboardHeight < viewHeight + 25)
    {
        [UIView animateWithDuration:0.2 animations:^{
            self.view.frame = CGRectMake(0, SCREENHEIGHT - (keyboardHeight + viewHeight + 25), SCREENWIDTH, SCREENHEIGHT);//视图的y值解析，使图像上跑，y是负值，(keyboardHeight + viewHeight + 25)这个是view的高度+键盘的高度，加上25，>屏幕的值就是向上跑的值。
        }];
    }
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
//点击任意位置回收键盘
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
    //界面恢复
    [UIView animateWithDuration:0.2 animations:^{
        self.view.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT);
    }];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self deleteDatabaseTable];
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userName"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"UserID"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"pubBtn"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"noPubBtn"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"diaryBtn"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"aboutBtn"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"groupType"];
    self.navigationController.navigationBar.hidden = YES;
}
//删除数据库
-(void)deleteDatabaseTable
{
    [[GetDataBase shareDataBase] wzDeleteReCordFromTableName:@"About"];
    [[GetDataBase shareDataBase] wzDeleteReCordFromTableName:@"Diary"];
    [[GetDataBase shareDataBase] wzDeleteReCordFromTableName:@"GroupPhoto"];
    [[GetDataBase shareDataBase] wzDeleteReCordFromTableName:@"PrivateGroup"];
    [[GetDataBase shareDataBase] wzDeleteReCordFromTableName:@"PublicGroup"];
    [[GetDataBase shareDataBase] wzDeleteReCordFromTableName:@"GroupIDFindArtID"];
}
@end
