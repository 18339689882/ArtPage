//
//  LoginViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "loginView.h"
@interface LoginViewController : PublicViewController

@property (nonatomic, strong)LoginView *loginView;

@end
