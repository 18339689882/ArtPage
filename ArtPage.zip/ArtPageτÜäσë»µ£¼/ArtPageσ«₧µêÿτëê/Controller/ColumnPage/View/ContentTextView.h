//
//  ContentTextView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TitleAndLineView.h"
@interface ContentTextView : UIView

@property (nonatomic,strong) TitleAndLineView *titleLineView;
@property (nonatomic,strong) UILabel *contentLab;

- (instancetype)initWithFrame:(CGRect)frame andStr:(NSString *)str;

@end
