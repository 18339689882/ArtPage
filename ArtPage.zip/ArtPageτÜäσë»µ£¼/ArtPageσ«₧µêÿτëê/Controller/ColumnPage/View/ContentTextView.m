//
//  ContentTextView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ContentTextView.h"

@implementation ContentTextView

- (instancetype)initWithFrame:(CGRect)frame andStr:(NSString *)str
{
    self = [super initWithFrame:frame];
    if (self)
    {        
        _titleLineView = [[TitleAndLineView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 60)];
        [self addSubview:_titleLineView];
        
        _contentLab = [[UILabel alloc] init];
        _contentLab.text = str;
        //自动获取文字高度
        CGSize titleSize = [_contentLab.text boundingRectWithSize:CGSizeMake(SCREENWIDTH - 40, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12.0]} context:nil].size;
        //设置行间距
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:_contentLab.text];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineSpacing:8.0];
        [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, _contentLab.text.length)];
        
        _contentLab.frame = CGRectMake(20, CGRectGetMaxY(self.titleLineView.frame) + 15, SCREENWIDTH - 40, titleSize.height);
        _contentLab.textColor = WSColorFromRGB(0x626262);
        _contentLab.numberOfLines = 0;
        [self addSubview:_contentLab];
        [_contentLab sizeToFit];
    }
    return self;
}
@end
