//
//  TitleAndLineView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleAndLineView : UIView

@property (nonatomic,strong) UILabel *titleLab;
@property (nonatomic,strong) UIImageView *lineView;

@end
