//
//  BasicMessView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "BasicMessView.h"

@implementation BasicMessView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _titleLineView = [[TitleAndLineView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 60)];
        _titleLineView.titleLab.text = @"基本信息";
        [self addSubview:_titleLineView];
        //得到数据库中的信息
        NSArray *dataArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"About"];
        NSString *nameStr = [dataArr[0] valueForKey:@"ARTIST_NAME_CN"];
        NSString *controlStr = [dataArr[0] valueForKey:@"ARTIST_LOCATION_COUNTRY_CN"];
        NSString *controlStr1 = [controlStr stringByAppendingString:@"  "];
        NSString *cityStr = [dataArr[0] valueForKey:@"ARTIST_LOCATION_CITY_CN"];
        NSString *cityStr1 = [controlStr1 stringByAppendingString:cityStr];
        NSString *sexStr = [dataArr[0] valueForKey:@"GENDER_CN"];
        NSString *toolStr = [dataArr[0] valueForKey:@"TOOL_CN"];
        NSString *goodStr = [dataArr[0] valueForKey:@"ARTIST_EXPERTISE_CN"];
        NSString *businessStr = [dataArr[0] valueForKey:@"AvailableForFreelance"];
        if([businessStr isEqualToString:@"1"])
        {
            businessStr = @"接收";
        }
        else
        {
            businessStr = @"不接受";
        }
        NSArray *inforMationStr = [NSArray arrayWithObjects:nameStr, cityStr1, sexStr, toolStr, goodStr, businessStr, nil];
        NSArray *titleArr = [NSArray arrayWithObjects:@"真实姓名", @"所在区域", @"性别", @"创作工具", @"擅长领域", @"商业委托", nil];
        for (int i = 0; i < 6; ++i)
        {
            _textLab = [[UILabel alloc] init];
            _textLab.text = titleArr[i];
            _textLab.textColor = WSColorFromRGB(0x626262);
            [_textLab setFont:[UIFont fontWithName:@"Helvetica-Bold" size:13]];
            [self addSubview:_textLab];
            [_textLab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.titleLineView.bottom).offset(15 + i * 30);
                make.left.equalTo(20);
                make.width.equalTo(55);
                make.height.equalTo(15);
            }];
            
            _detailLab = [[UILabel alloc] init];
            _detailLab.text = inforMationStr[i];
            _detailLab.textColor = WSColorFromRGB(0x626262);
            _detailLab.font = [UIFont systemFontOfSize:13];
            [self addSubview:_detailLab];
            [_detailLab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.titleLineView.bottom).offset(15 + i * 30);
                make.left.equalTo(self.textLab.right).offset(15);
                make.width.equalTo(180);
                make.height.equalTo(15);
            }];
        }
    }
    return self;
}

@end
