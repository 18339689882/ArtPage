//
//  ColumnView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ColumnView.h"

@implementation ColumnView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
