//
//  TitleAndLineView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "TitleAndLineView.h"

@implementation TitleAndLineView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _titleLab = [[UILabel alloc] init];
        _titleLab.font = [UIFont systemFontOfSize:20];
        _titleLab.textColor = WSColorFromRGB(0xa0a0a0);
        [_titleLab setFont:[UIFont fontWithName:@"Helvetica-Bold" size:20]];
        [self addSubview:_titleLab];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.equalTo(20);
            make.width.equalTo(80);
            make.height.equalTo(20);
        }];
        
        _lineView = [[UIImageView alloc] init];
        _lineView.backgroundColor = [UIColor grayColor];
        [self addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLab.bottom).offset(20);
            make.left.equalTo(0);
            make.width.equalTo(SCREENWIDTH);
            make.height.equalTo(0.5);
        }];
    }
    return self;
}

@end
