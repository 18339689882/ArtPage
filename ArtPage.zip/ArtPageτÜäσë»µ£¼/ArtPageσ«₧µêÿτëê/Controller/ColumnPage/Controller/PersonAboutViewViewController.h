//
//  PersonAboutViewViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonAboutViewViewController : PublicViewController

@end
