//
//  ColumnViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "ColumnViewController.h"
#import "ColumnView.h"
#import "ShareViewController.h"
#import "PersonAboutViewViewController.h"
#import "DiaryTableViewController.h"
#import "IndexTableViewCell.h"
@interface ColumnViewController ()
@property (nonatomic, strong)ColumnView *setSixSectionView;
@property (nonatomic,strong) IndexTableViewCell *cell;

@end

@implementation ColumnViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //显示关闭
    [self setTabbar:NO andClose:YES];
    //显示logo
    [self setLeftLogo:YES];
    //初始化设置页面。
    [self initSetView];
}

-(void)initSetView
{
    _setSixSectionView = [[ColumnView alloc] initWithFrame:CGRectMake(0, 315, SCREENWIDTH, 168)];
    __weak typeof(self) weskSelf = self;
    //更换图片
    [self setBtn:_setSixSectionView.copLinkBtn andPhotoName:@"btn_公开作品" andSelectName:@"btn_公开作品_d"];
    _setSixSectionView.firstBlock = ^(SixSectionView *firstBlock) {
        setDefault(@"public", @"groupType");
        [weskSelf.navigationController popViewControllerAnimated:YES];
    };
    [self setBtn:_setSixSectionView.weiChatBtn andPhotoName:@"btn_非公开作品" andSelectName:@"btn_非公开作品_d"];
    _setSixSectionView.secondBlock = ^(SixSectionView *firstBlock) {
        setDefault(@"private", @"groupType");
        [weskSelf.navigationController popViewControllerAnimated:YES];
    };
    [self setBtn:_setSixSectionView.friendCycleBtn andPhotoName:@"btn_关于" andSelectName:@"btn_关于_d"];
    _setSixSectionView.thirdBlock = ^(SixSectionView *firstBlock) {
        [weskSelf.navigationController pushViewController:[[PersonAboutViewViewController alloc] init] animated:YES];
    };
    [self setBtn:_setSixSectionView.sinaBtn andPhotoName:@"btn_日志" andSelectName:@"btn_日志@_d"];
    _setSixSectionView.fourBlock = ^(SixSectionView *firstBlock) {
        [weskSelf.navigationController pushViewController:[[DiaryTableViewController alloc] init] animated:YES];
    };
    [self setBtn:_setSixSectionView.messageBtn andPhotoName:@"btn_推送主页链接" andSelectName:@""];
    _setSixSectionView.fiveBlock = ^(SixSectionView *firstBlock) {
        [weskSelf.navigationController pushViewController:[[ShareViewController alloc] init] animated:YES];
    };
    [self setBtn:_setSixSectionView.emailBtn andPhotoName:@"btn_切换英文" andSelectName:@"btn_切换中文"];
    
    _setSixSectionView.sixBlock = ^(SixSectionView *firstBlock) {
        if([gainDefault(@"charType") isEqualToString:@"english"])
        {
            //切换中文
            setDefault(@"chinese", @"charType");
        }
        else
        {
            //切换为english
            setDefault(@"english", @"charType");
        }
        NSLog(@"切换中英文");
    };
    [self.view addSubview:_setSixSectionView];
}

-(void)setBtn:(UIButton *)btn andPhotoName:(NSString *)photoName andSelectName:(NSString *)selName
{
    [btn setImage:[UIImage imageNamed:photoName] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:selName] forState:UIControlStateSelected];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self hiddenView:@"pubBtn" andBtn:self.setSixSectionView.copLinkBtn];
    [self hiddenView:@"noPubBtn" andBtn:self.setSixSectionView.weiChatBtn];
    [self hiddenView:@"diaryBtn" andBtn:self.setSixSectionView.sinaBtn];
    [self hiddenView:@"aboutBtn" andBtn:self.setSixSectionView.friendCycleBtn];
    
    if ([gainDefault(@"charType") isEqualToString:@"chinese"])
    {
        NSLog(@"%@", gainDefault(@"charType"));
        _setSixSectionView.emailBtn.selected = NO;
    }
    else
    {
        NSLog(@"%@", gainDefault(@"charType"));
        _setSixSectionView.emailBtn.selected = YES;
    }
}

-(void)hiddenView:(NSString *)btnStr andBtn:(UIButton *)btn
{
    if([gainDefault(btnStr) isEqualToString:@"1"])
    {
        btn.hidden = YES;
    }
    else
    {
        btn.hidden = NO;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
