//
//  PersonAboutViewViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/5.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PersonAboutViewViewController.h"
#import "IndexBottomView.h"
#import "ColumnViewController.h"
#import "SetViewController.h"
#import "BasicMessView.h"
#import "ContentTextView.h"
@interface PersonAboutViewViewController ()

@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) IndexBottomView *indexBtn;
@property (nonatomic,strong) BasicMessView *basicMessView;
@property (nonatomic,strong) ContentTextView *contentTextView;

@end

@implementation PersonAboutViewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //顶部显示用户名
    [self setHeaderTitle:YES];
    //底部button
    [self setButtonItem];
    //加载scrollView
    [self initScrollView];
    //加载图片
    [self initPhotoView];
    //初始化个人信息
    [self initbasicMessView];
    //初始化内容信息
    [self initContentView];
}
//加载scrollView
-(void)initScrollView
{
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT - 60)];
    [self.view addSubview:_scrollView];
}
//底部button
-(void)setButtonItem
{
    _indexBtn = [[IndexBottomView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT - 54, SCREENWIDTH, 54)];
    [self.view addSubview:_indexBtn];
    //跳转到栏目页面
    __weak typeof(self) weakSelf = self;
    _indexBtn.columnBtnBlock = ^(IndexBottomView *indexBtnBlock) {
        [weakSelf.navigationController popViewControllerAnimated:YES];
    };
    //跳转到设置页面
    _indexBtn.setBtnBlock = ^(IndexBottomView *indexBtnBlock) {
        [weakSelf.navigationController pushViewController:[[SetViewController alloc] init] animated:YES];
    };
    _indexBtn.layer.zPosition = 1.0;
}
//加载图片
-(void)initPhotoView
{
    UIImageView *aboutImgView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 50, 110, 150)];
    aboutImgView.image = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Library/Caches/%@/aboutPhoto/about0.jpg", NSHomeDirectory(), gainDefault(@"userName")]];
    [self.scrollView addSubview:aboutImgView];
}
//初始化个人信息
-(void)initbasicMessView
{
    _basicMessView = [[BasicMessView alloc] initWithFrame:CGRectMake(0, 220, SCREENWIDTH, 240)];
    [self.scrollView addSubview:_basicMessView];
}
//初始化内容信息
-(void)initContentView
{
    //从数据库获得信息
    NSString *jobExpericeStr;
    NSString *serviceCountStr;
    NSString *honorStr;
    NSArray *dataArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"About"];
    jobExpericeStr = [dataArr[0] valueForKey:@"ARTIST_RESUME_CN"];
    if([gainDefault(@"charType") isEqualToString:@"english"])
        jobExpericeStr = [dataArr[0] valueForKey:@"ARTIST_RESUME_EN"];
    serviceCountStr = [dataArr[0] valueForKey:@"CUSTOM_CN"];
    if([gainDefault(@"charType") isEqualToString:@"english"])
        serviceCountStr = [dataArr[0] valueForKey:@"CUSTOM_EN"];
    honorStr = [dataArr[0] valueForKey:@"ARTIST_HuoJiangJingLi_CN"];
    if([gainDefault(@"charType") isEqualToString:@"english"])
        honorStr = [dataArr[0] valueForKey:@"ARTIST_HuoJiangJingLi_EN"];
    NSArray *contentStr = [NSArray arrayWithObjects:jobExpericeStr, serviceCountStr, honorStr, nil];
    float originY = CGRectGetMaxY(self.basicMessView.frame);
    NSArray *titleArr = [NSArray arrayWithObjects:@"工作经历", @"服务客户", @"所获荣誉", nil];
    for (int i = 0; i < 3; ++i)
    {
        _contentTextView = [[ContentTextView alloc] initWithFrame:CGRectZero andStr:contentStr[i]];
        _contentTextView.titleLineView.titleLab.text = titleArr[i];
        _contentTextView.frame = CGRectMake(0, originY + 10, SCREENWIDTH, CGRectGetMaxY(self.contentTextView.contentLab.frame));
        [self.scrollView addSubview:_contentTextView];
        originY = CGRectGetMaxY(self.contentTextView.frame);
    }
    self.scrollView.contentSize = CGSizeMake(SCREENWIDTH, CGRectGetMaxY(self.contentTextView.frame));
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
