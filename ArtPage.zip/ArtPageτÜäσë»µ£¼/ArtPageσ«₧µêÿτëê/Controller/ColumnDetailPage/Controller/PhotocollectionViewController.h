//
//  PhotoCollocationViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/7.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoCollocationViewController : PublicViewController

@property (nonatomic,strong) UILabel *titleLab;
@property (nonatomic,assign) NSString *groupID;

@end
