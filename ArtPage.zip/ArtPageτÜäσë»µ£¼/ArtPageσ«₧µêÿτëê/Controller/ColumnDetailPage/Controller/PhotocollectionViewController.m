//
//  PhotoCollocationViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/7.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PhotocollectionViewController.h"
#import "MyPhotoCollectionViewCell.h"
#import "PhotoDetailCollectionViewController.h"
#import "PhotoDetailCollectionViewCell.h"
@interface PhotoCollocationViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout >

@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) NSMutableArray *collectionViewDataSourceArr;

@property (nonatomic,strong) UILabel *headLab;
@property (nonatomic,strong) UILabel *numLab;

//ArtWorkID数组
@property (nonatomic,strong) NSArray *artArr;

@end

@implementation PhotoCollocationViewController


//懒加载collectionView
-(UICollectionView *)collectionView
{
    if(!_collectionView)
    {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 60, SCREENWIDTH, SCREENHEIGHT - 130) collectionViewLayout:flowLayout];
        
        //遵循代理
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
        //注册视图
        [_collectionView registerClass:[MyPhotoCollectionViewCell class] forCellWithReuseIdentifier:@"MyPhotoCollectionViewCell"];
        //注册头部视图
        [_collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"UICollectionElementKindSectionHeader"];
    }
    return _collectionView;
}

//懒加载titleLab
-(UILabel *)titleLab
{
    if(!_titleLab)
    {
        _titleLab = [[UILabel alloc] init];
    }
    return _titleLab;
}
//懒加载artArr
-(NSArray *)artArr
{
    if (!_artArr)
    {
        _artArr = [NSArray array];
    }
    return _artArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //显示用户名
    [self setHeaderTitle:YES];
    //显示返回按钮
    [self setTabbar:YES andClose:NO];
    
    [self initCollectionViewDataSource];
    [self.view addSubview:self.collectionView];
}

//初始化collectionViewDataSource
-(void)initCollectionViewDataSource
{
    _collectionViewDataSourceArr = [NSMutableArray arrayWithCapacity:1];
    NSDictionary *dic = @{@"GroupID":self.groupID};
    NSArray * photoArr = [[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupIDFindArtID" andDicitonary:dic];
    NSLog(@"%ld", photoArr.count);
    for (int i = 0; i < photoArr.count; ++i)
    {
        [_collectionViewDataSourceArr addObject:[NSString stringWithFormat:@"%d", i]];
    }
}

#pragma --collectionViewDataSource------
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.collectionViewDataSourceArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MyPhotoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyPhotoCollectionViewCell" forIndexPath:indexPath];
    //通过GroupID找到artWorkID
    NSDictionary *artDic = @{@"GroupID":self.groupID};
    self.artArr = [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupIDFindArtID" andDicitonary:artDic] valueForKey:@"ArtWorkID"];
//    NSLog(@"artArr = %@", self.artArr);
    
    //拼接图片路径。
    NSString *pathStr = [NSString stringWithFormat:@"%@/Library/Caches/%@/THUMBNAILPhoto/%@/%@.jpg", NSHomeDirectory(), gainDefault(@"userName"), self.groupID, self.artArr[indexPath.row]];
    //判断路径是否存在，设置cell图片。
    if(pathStr)
    {
       cell.photoImgView.image = [UIImage imageWithContentsOfFile:pathStr];
    }
    else{
        cell.photoImgView.image = [UIImage imageNamed:@"share"];
    }
    return  cell;
}
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if([kind isEqualToString:UICollectionElementKindSectionHeader])
    {
        UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"UICollectionElementKindSectionHeader" forIndexPath:indexPath];
        
        //加载tou视图
        [self setCollectionHeadetView];
        
        [headerView addSubview:self.headLab];
        [headerView addSubview:self.numLab];
        
        return headerView;
    }
    
    return nil;
}

#pragma --------------UICollectionViewDelegateFlowLayout------------
//每一个块的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return (CGSize){(SCREENWIDTH - 50) / 4, (SCREENWIDTH - 50) / 4};
}
//行间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 10;
}
//列间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 10;
}
//页眉
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return (CGSize){375,60};
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section;
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma ------------UICollectionViewDelegate--------------
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"您选择了第%ld个图片", indexPath.row + 1);
    PhotoDetailCollectionViewController *tempVC = [[PhotoDetailCollectionViewController alloc] init];
    //传递一个inde
    tempVC.index = indexPath.row;
    //传递GroupID
    tempVC.groupId = self.groupID;
    [self.navigationController pushViewController:tempVC animated:YES];
}

#pragma -------头部视图-------------------
-(void)setCollectionHeadetView
{
    UILabel *phoTitleLab = [[UILabel alloc] init];
    phoTitleLab.text = self.titleLab.text;
    phoTitleLab.textColor = [UIColor grayColor];
    phoTitleLab.font = [UIFont systemFontOfSize:20];
    phoTitleLab.frame = CGRectMake(10, 10, SCREENWIDTH, 20);
    self.headLab = phoTitleLab;
    
    UILabel *phoNumLab = [[UILabel alloc] init];
    phoNumLab.text = [NSString stringWithFormat:@"%ld个项目", self.artArr.count];
    phoNumLab.textColor = [UIColor grayColor];
    phoNumLab.font = [UIFont systemFontOfSize:16];
    phoNumLab.frame = CGRectMake(10, 35, 120, 20);
    self.numLab = phoNumLab;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
