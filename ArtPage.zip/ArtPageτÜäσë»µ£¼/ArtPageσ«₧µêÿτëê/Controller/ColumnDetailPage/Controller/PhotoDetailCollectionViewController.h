//
//  PhotoDetailCollectionViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoDetailCollectionViewController : UIViewController

@property (nonatomic, assign) NSInteger index;
@property (nonatomic, strong) NSString *groupId;

@end
