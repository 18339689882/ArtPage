//
//  PhotoDetailCollectionViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PhotoDetailCollectionViewController.h"
#import "PhotoDetailCollectionViewCell.h"
#import "PhotoDetailLabView.h"
#import "PhotoSavedLabView.h"
@interface PhotoDetailCollectionViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
{
    int t;
    NSIndexPath *index;
    NSInteger realScreenWidth;
    NSInteger realScreenHeight;
}
@property (nonatomic,strong) UICollectionViewFlowLayout *flowLayout;
@property (nonatomic,strong) PhotoDetailLabView *photoDetailLabView;

@property (nonatomic,strong) NSMutableArray *collectionDataSource;
@property (nonatomic,strong) UICollectionView *collectionView;

@property (nonatomic,strong) NSArray *photoArtIdArr;

//返回按钮
@property (nonatomic,strong) UIButton *backBtn;
//保存图片按钮
@property (nonatomic,strong) UIButton *saveBtn;

@property (nonatomic,strong) PhotoDetailCollectionViewCell *cell;

@property (nonatomic,strong) PhotoSavedLabView *saveSuccessView;

@end

@implementation PhotoDetailCollectionViewController
//初始化data数据
-(void)initCollectionDataSource
{
    if(!_collectionDataSource)
    {
        _collectionDataSource = [NSMutableArray arrayWithCapacity:1];
        
        //字典 表格中第一个GroupID的字典。
        NSDictionary *dic = @{@"GroupID":self.groupId};
        
        //获得GroupID为表中第一个GroupID的所有ArtWorkID
        self.photoArtIdArr = [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupIDFindArtID" andDicitonary:dic] valueForKey:@"ArtWorkID"];
        
        for (int i = 0; i < self.photoArtIdArr.count; ++i)
        {
            [_collectionDataSource addObject:[NSString stringWithFormat:@"%d", i]];
        }
    }
}

//初始化collectionView
-(UICollectionView *)collectionView
{
    if(!_collectionView)
    {
        //初始化collectionView
        _flowLayout = [[UICollectionViewFlowLayout alloc] init];
        _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:_flowLayout];
        
        //设置滑动方向
        _collectionView.pagingEnabled = YES;

        //注册cell
        [_collectionView registerClass:[PhotoDetailCollectionViewCell class] forCellWithReuseIdentifier:@"PhotoDetailCollectionViewCell"];
        
        //确定选择了第几张图片
        _collectionView.contentOffset = CGPointMake(SCREENWIDTH * self.index, 0);
        
        //遵循代理
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
    }
    return _collectionView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    [self initCollectionDataSource];
    
    realScreenWidth = SCREENWIDTH;
    realScreenHeight = SCREENHEIGHT;
    
    //加载视图collectionView
    [self.view addSubview:self.collectionView];
    //加载底部按钮
    [self initBackBtnAndSaveBtn];
}
-(void)initBackBtnAndSaveBtn
{
    _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _backBtn.userInteractionEnabled = YES;
    [_backBtn setImage:[UIImage imageNamed:@"btn_返回"] forState:UIControlStateNormal];
    [_backBtn addTarget:self action:@selector(backMethod) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_backBtn];
    [_backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(-10);
        make.left.equalTo(98);
        make.height.width.equalTo(50);
    }];
    
    _saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _saveBtn.userInteractionEnabled = YES;
    [_saveBtn setImage:[UIImage imageNamed:@"btn_保存至相册"] forState:UIControlStateNormal];
    [_saveBtn addTarget:self action:@selector(saveMethod) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_saveBtn];
    [_saveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(-10);
        make.right.equalTo(-82);
        make.height.width.equalTo(50);
    }];
}
-(void)backMethod
{
    [self.navigationController popViewControllerAnimated:YES];
}
//保存图片
-(void)saveMethod
{
    UIImageWriteToSavedPhotosAlbum(self.cell.photoImgView.image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
}
// 指定回调方法
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if(!error){
        NSLog(@"save success");
        [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(timeChange:) userInfo:nil repeats:NO];
        _saveSuccessView = [[PhotoSavedLabView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 55)];
        _saveSuccessView.backgroundColor = rgb(52.0/255, 50.0/255, 27.0/255);
        [self.view addSubview:_saveSuccessView];
        
    }else{
        NSLog(@"save failed");
    }
}
- (void)timeChange:(NSTimer *)sender{
    __weak typeof(self) weakSelf = self;
    [UIView animateWithDuration:0 animations:^{
        weakSelf.saveSuccessView.hidden = YES;
    }];
}

- (void)scrollViewDidEndDecelerating:(UICollectionView *)collectionView
{
    CGPoint pointView = [self.view convertPoint:self.collectionView.center toView:self.collectionView];
    index = [collectionView indexPathForItemAtPoint:pointView];
    NSLog(@"index = %ld", (long)index.row);
    
    self.cell.photoImgView.frame = CGRectMake(0, 0, realScreenWidth, realScreenHeight);
}
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    NSLog(@"size.width = %lf, size.height = %lf", size.width, size.height);
    
    realScreenHeight = size.height;
    realScreenWidth = size.width;
    
    [self reuseCollectionViewReversal];
}

-(void)reuseCollectionViewReversal
{
    self.collectionView.frame = CGRectMake(0, 0, realScreenWidth, realScreenHeight);
    self.flowLayout.itemSize = CGSizeMake(self.collectionView.frame.size.width,self.collectionView.frame.size.height);
    [self.collectionView layoutIfNeeded];
    [self.collectionView reloadData];
    
    self.collectionView.contentSize = CGSizeMake(12 * realScreenWidth, realScreenHeight);
    
    CGPoint contentoffset = CGPointMake(realScreenWidth * index.row, 0);
    self.collectionView.contentOffset = contentoffset;
    
    for (UIView *image in [self.collectionView subviews])
    {
        if([image isKindOfClass:[UIImageView class]])
        {
            self.cell.photoImgView.frame = CGRectMake(0, 0, realScreenWidth, realScreenHeight);
        }
    }
}
#pragma -------------UICollectionViewDataSource--------------
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _collectionDataSource.count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //初始化t的值
    t = 0;
    self.cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoDetailCollectionViewCell" forIndexPath:indexPath];
    
    //添加点击手势
    UITapGestureRecognizer *gester = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickPhoto:)];
    gester.numberOfTouchesRequired = 1;
    [self.cell addGestureRecognizer:gester];
    
    //拼接图片路径。
    NSString *pathStr = [NSString stringWithFormat:@"%@/Library/Caches/%@/originPhoto/%@/%@.jpg", NSHomeDirectory(), gainDefault(@"userName"), self.groupId, self.photoArtIdArr[indexPath.row]];
    
    if(indexPath.row <= self.collectionDataSource.count)
    {
        _cell.photoImgView.image = [UIImage imageWithContentsOfFile:pathStr];
    }
    return _cell;
}

#pragma -------------UICollectionViewDelegateFlowLayout--------------
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    return (CGSize){SCREENWIDTH, SCREENHEIGHT - 60};
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

#pragma mark----------UICollectionViewDelegate-----------
//视图将要出现的时候，让label消失。
- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    self.photoDetailLabView.hidden = YES;
}
//响应手势，获得当前位置
-(void)clickPhoto:(UITapGestureRecognizer *)tapGesture
{
    ++t;
    if(t % 2)
    {
        NSIndexPath *clickedIndexPath = [self.collectionView indexPathForItemAtPoint:[tapGesture locationInView:self.collectionView]];
        //找到当前的cell
        PhotoDetailCollectionViewCell *cell = (PhotoDetailCollectionViewCell *)[self.collectionView cellForItemAtIndexPath:clickedIndexPath];
        
        _photoDetailLabView = [[PhotoDetailLabView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT / 2, SCREENWIDTH, SCREENHEIGHT / 2 - 60)];
        
//        NSLog(@"%ld", clickedIndexPath.row);
//        NSLog(@"%@", self.photoArtIdArr[clickedIndexPath.row]);
        //找到对应的图片的ArtWorkID
        NSDictionary *ArtDic = @{@"ArtWorkID":self.photoArtIdArr[clickedIndexPath.row]};
        //从数据库中找到图片对应的标题和文字描述
        NSArray * titleArr;
        NSArray *contentArr;
        titleArr = [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupPhoto" andDicitonary:ArtDic] valueForKey:@"ARTWORK_NAME_CN"];
        if([gainDefault(@"charType") isEqualToString:@"english"])
            titleArr = [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupPhoto" andDicitonary:ArtDic] valueForKey:@"ARTWORK_NAME_EN"];
        contentArr = [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupPhoto" andDicitonary:ArtDic] valueForKey:@"ARTWORK_DESC_CN"];
        if([gainDefault(@"charType") isEqualToString:@"english"])
            contentArr = [[[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupPhoto" andDicitonary:ArtDic] valueForKey:@"ARTWORK_DESC_EN"];
        //给视图的text赋值
        _photoDetailLabView.titleLab.text = titleArr[0];
        _photoDetailLabView.contentLab.text = contentArr[0];
        
        _photoDetailLabView.backgroundColor = [UIColor colorWithRed:52.0/255 green:50.0/255 blue:27.0/255 alpha:0.5];
        [cell addSubview:_photoDetailLabView];
    }
    else
    {
        self.photoDetailLabView.hidden = YES;
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    self.photoDetailLabView.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
