//
//  PhotoSavedLabView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PhotoSavedLabView.h"

@implementation PhotoSavedLabView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _photoSavedLab = [[UILabel alloc] init];
        _photoSavedLab.text = @"图片已保存到相册";
        _photoSavedLab.textAlignment = NSTextAlignmentCenter;
        _photoSavedLab.font = [UIFont systemFontOfSize:20];
        _photoSavedLab.textColor = WSColorFromRGB(0xa0a0a0);
        [self addSubview:_photoSavedLab];
        [_photoSavedLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.centerY);
            make.centerX.equalTo(self.centerX);
            make.width.equalTo(SCREENWIDTH);
            make.height.equalTo(20);
        }];
    }
    return self;
}

@end
