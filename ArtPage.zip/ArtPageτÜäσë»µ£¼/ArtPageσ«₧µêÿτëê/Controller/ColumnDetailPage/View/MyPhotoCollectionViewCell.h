//
//  MyPhotoCollectionViewCell.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPhotoCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UIImageView *photoImgView;

@end
