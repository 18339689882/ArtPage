//
//  PhotoDetailCollectionViewCell.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PhotoDetailCollectionViewCell.h"
#import "PhotoDetailLabView.h"
@implementation PhotoDetailCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _photoImgView = [[UIImageView alloc] init];
        _photoImgView.frame = CGRectMake(0, 64, self.frame.size.width, self.frame.size.height - 64 - 49);
        //按照图片比例显示图片
        _photoImgView.contentMode = UIViewContentModeScaleAspectFit;
        
        [self.contentView addSubview:_photoImgView];
    }
    return self;
}

-(void)setCellData:(id)cellData
{
    self.photoImgView.image = cellData;
}

@end
