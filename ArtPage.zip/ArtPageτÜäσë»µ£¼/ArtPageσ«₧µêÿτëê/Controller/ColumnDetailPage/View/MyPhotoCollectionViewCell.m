//
//  MyPhotoCollectionViewCell.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "MyPhotoCollectionViewCell.h"

@implementation MyPhotoCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _photoImgView = [[UIImageView alloc] init];
        _photoImgView.frame = CGRectMake(0, 0, (SCREENWIDTH - 50) / 4, (SCREENWIDTH - 50) / 4);
        [self.contentView addSubview:_photoImgView];
    }
    return self;
}

@end
