//
//  PhotoDetailLabView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoDetailLabView : UIView

@property (nonatomic,strong) UILabel *titleLab;
@property (nonatomic,strong) UILabel *contentLab;

@end
