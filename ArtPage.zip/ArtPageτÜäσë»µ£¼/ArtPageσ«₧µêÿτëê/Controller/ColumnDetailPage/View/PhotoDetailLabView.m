//
//  PhotoDetailLabView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/8.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PhotoDetailLabView.h"

@implementation PhotoDetailLabView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _titleLab = [[UILabel alloc] init];
//        _titleLab.text = @"作品标题";
        _titleLab.textAlignment = NSTextAlignmentLeft;
        _titleLab.font = [UIFont systemFontOfSize:18];
        _titleLab.textColor = WSColorFromRGB(0xa0a0a0);
        [self addSubview:_titleLab];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(30);
            make.left.equalTo(30);
            make.width.equalTo(SCREENWIDTH - 60);
            make.height.equalTo(20);
        }];
        
        _contentLab = [[UILabel alloc] init];
//        _contentLab.text = @"作品内容";
        _contentLab.numberOfLines = 0;
        _contentLab.textAlignment = NSTextAlignmentLeft;
        _contentLab.font = [UIFont systemFontOfSize:18];
        _contentLab.textColor = WSColorFromRGB(0xa0a0a0);
        [self addSubview:_contentLab];
        [_contentLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLab.bottom).offset(40);
            make.left.equalTo(30);
            make.width.equalTo(SCREENWIDTH - 60);
            make.height.equalTo(100);
        }];
    }
    return self;
}

@end
