//
//  PublicViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PublicViewController : UIViewController

@property (nonatomic, strong)UILabel *nameLab;

@property (nonatomic, strong)UIButton *backBtn;
//控制底部按钮返回按钮和关闭按钮
-(void)setTabbar:(BOOL)back andClose:(BOOL)close;
//控制logo
-(void)setLeftLogo:(BOOL)leftLogo;
//控制用户名
-(void)setHeaderTitle:(BOOL)title;

//弹窗
-(void)showAlertView:(NSString *)msg andMessage:(NSString *)message;

@end
