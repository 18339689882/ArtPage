//
//  PublicViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/26.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PublicViewController.h"

@interface PublicViewController ()



@end

@implementation PublicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
}

-(void)setHeaderTitle:(BOOL)title
{
    if(title == YES)
    {
        [self setHeaderTitle];
    }
    else
    {
        ;
    }
}

-(void)setTabbar:(BOOL)back andClose:(BOOL)close//back == YES 显示返回 close == YES显示关闭
{
    if(back == YES && close == NO)
    {
        [self BackBtn:@"btn_返回"];
    }
    if(close == YES && back == NO)
    {
        [self BackBtn:@"btn_关闭"];
    }
    else
    {
        ;
    }
}

-(void)setLeftLogo:(BOOL)leftLogo//leftLogo is YES 显示左边logo
{
    if(leftLogo == YES)
    {
        [self setLeftLogo];
    }
}

-(void)setHeaderTitle
{
    //设置顶部title
    NSString *titleName = gainDefault(@"userName");
    _nameLab = [[UILabel alloc] init];
    _nameLab.textColor = [UIColor grayColor];
    _nameLab.textAlignment = NSTextAlignmentCenter;
    _nameLab.font = [UIFont systemFontOfSize:20];
    _nameLab.text = titleName;
    [self.view addSubview:_nameLab];
    _nameLab.layer.zPosition = 1.0;
    [_nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(20);
        make.centerX.equalTo(self.view.centerX);
        make.width.equalTo(SCREENWIDTH);
        make.height.equalTo(20);
    }];
}

-(void)setLeftLogo
{
    UIImageView *logoImgView = [[UIImageView alloc] init];
    logoImgView.image = [UIImage imageNamed:@"img_首页Logo"];
    [self.view addSubview:logoImgView];
    [logoImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(40);
        make.left.equalTo(20);
        make.height.equalTo(28);
        make.width.equalTo(85);
    }];
}

-(void)BackBtn:(NSString *)ImgStr
{
    _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _backBtn.userInteractionEnabled = YES;
    [_backBtn setImage:[UIImage imageNamed:ImgStr] forState:UIControlStateNormal];
    [_backBtn addTarget:self action:@selector(backMethod) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_backBtn];
    [_backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(-10);
        make.centerX.equalTo(self.view.centerX);
        make.height.width.equalTo(50);
    }];
}
-(void)backMethod
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)showAlertView:(NSString *)msg andMessage:(NSString *)message
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:msg delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alertView show];
}

@end
