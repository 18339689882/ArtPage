//
//  MyDiaryTableViewCell.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "MyDiaryTableViewCell.h"
#import "Diary.h"
@implementation MyDiaryTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}
//初始化cell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        //左边图片
        _mainImgView = [[UIImageView alloc] init];
        _mainImgView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_mainImgView];
        [_mainImgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(10);
            make.left.equalTo(10);
            make.width.height.equalTo(90);
        }];
        //栏目
        _titleLab = [[UILabel alloc] init];
        _titleLab.textAlignment = NSTextAlignmentLeft;
        _titleLab.textColor = WSColorFromRGB(0xa0a0a0);
        _titleLab.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_titleLab];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(32);
            make.left.equalTo(self.mainImgView.right).offset(25);
            make.width.equalTo(SCREENWIDTH - 160);
            make.height.equalTo(20);
        }];
        //一个项目
        _numLab = [[UILabel alloc] init];
        _numLab.textColor = WSColorFromRGB(0x626262);
        _numLab.font = [UIFont systemFontOfSize:11];
        [self.contentView addSubview:_numLab];
        [_numLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLab.bottom).offset(10);
            make.left.equalTo(self.mainImgView.right).offset(25);
            make.width.equalTo(100);
            make.height.equalTo(12);
        }];
        //右按钮
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_rightBtn setImage:[UIImage imageNamed:@"btn_分享"] forState:UIControlStateNormal];
        [_rightBtn addTarget:self action:@selector(interShare) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_rightBtn];
        [_rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(34);
            make.right.equalTo(-18);
            make.height.width.equalTo(22);
        }];
    }
    return self;
}

-(void)setModel:(Diary *)obj
{
   
    self.titleLab.text = obj.NAME_CN;
     if([gainDefault(@"charType") isEqualToString:@"english"])
         self.titleLab.text = obj.NAME_EN;
    self.numLab.text = obj.SUBMIT_DATE;
}

//跳转分享页面
-(void)interShare
{
    if(_jumpSharePage)
    {
        _jumpSharePage(self);
    }
}
@end
