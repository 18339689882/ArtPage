//
//  MyDiaryTableViewCell.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyDiaryTableViewCell : UITableViewCell

//栏目中内容。
@property (nonatomic, strong)UIImageView *mainImgView;
@property (nonatomic, strong)UILabel *titleLab;
@property (nonatomic, strong)UILabel *numLab;
@property (nonatomic, strong)UIButton *rightBtn;

//进入分享详情
typedef void(^sharePage)(UITableViewCell *indexViewBlock);
@property (nonatomic, copy)sharePage jumpSharePage;

-(void)setModel:(id)obj;

@end
