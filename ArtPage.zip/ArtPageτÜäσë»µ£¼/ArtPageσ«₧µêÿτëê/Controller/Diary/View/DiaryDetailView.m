//
//  DiaryDetailView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "DiaryDetailView.h"

@implementation DiaryDetailView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        //标题
        _titleLab = [[UILabel alloc] init];
        _titleLab.textColor = WSColorFromRGB(0xa0a0a0);
        _titleLab.font = [UIFont systemFontOfSize:20];
        _titleLab.numberOfLines = 0;
        _titleLab.textAlignment = NSTextAlignmentLeft;
        [self addSubview:_titleLab];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.left.equalTo(25);
            make.width.equalTo(SCREENWIDTH - 50);
            make.height.equalTo(50);
        }];
        //时间
        _timeLab = [[UILabel alloc] init];
        _timeLab.textColor = WSColorFromRGB(0x626262);
        _timeLab.font = [UIFont systemFontOfSize:11];
        _timeLab.textAlignment = NSTextAlignmentLeft;
        [self addSubview:_timeLab];
        [_timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLab.bottom).offset(10);
            make.left.equalTo(25);
            make.width.equalTo(100);
            make.height.equalTo(20);
        }];
        
        //正文
        _contentLab = [[UILabel alloc] init];
        _contentLab.textColor = WSColorFromRGB(0x626262);
        _contentLab.font = [UIFont systemFontOfSize:14];
        _contentLab.numberOfLines = 0;
        _contentLab.textAlignment = NSTextAlignmentLeft;
        [self addSubview:_contentLab];
        [_contentLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.timeLab.bottom).offset(15);
            make.left.equalTo(25);
            make.width.equalTo(SCREENWIDTH - 50);
        }];
    }
    return self;
}

@end
