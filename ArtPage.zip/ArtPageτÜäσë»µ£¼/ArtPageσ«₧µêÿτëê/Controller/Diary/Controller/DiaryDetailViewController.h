//
//  DiaryDetailViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PublicViewController.h"

@interface DiaryDetailViewController : PublicViewController

@property (nonatomic,strong) UILabel *titleLab;

@end
