//
//  DiaryTableViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "DiaryTableViewController.h"
#import "IndexBottomView.h"
#import "ColumnViewController.h"
#import "SetViewController.h"
#import "MyDiaryTableViewCell.h"
#import "ShareViewController.h"
#import "DiaryDetailViewController.h"
#import "Diary.h"
@interface DiaryTableViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic,strong) IndexBottomView *bottomBtnView;
@property (nonatomic,strong) UITableView *aTableView;

//数据源
@property (nonatomic,strong) NSMutableArray *tableViewDataArr;

@property (nonatomic,strong) MyDiaryTableViewCell *cell;

@property (nonatomic,strong) Diary *model;
@end

@implementation DiaryTableViewController
//懒加载tableViewDataArr
-(NSMutableArray *)tableViewDataArr
{
    if(!_tableViewDataArr)
    {
        _tableViewDataArr = [NSMutableArray arrayWithCapacity:1];
        _tableViewDataArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"Diary"];
    }
    return _tableViewDataArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //显示用户名
    [self setHeaderTitle:YES];
    //设置底部按钮
    [self setBottomBtn];
    //初始化tableView
    [self initTableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//初始化tableView
-(void)initTableView
{
    _aTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 60, SCREENWIDTH, SCREENHEIGHT - 120) style:UITableViewStylePlain];
    _aTableView.backgroundColor = [UIColor blackColor];
    //注册cell
    [_aTableView registerClass:[MyDiaryTableViewCell class] forCellReuseIdentifier:@"MyDiaryTableViewCell"];
    
    //遵循代理
    _aTableView.delegate = self;
    _aTableView.dataSource = self;
    
    [self.view addSubview:_aTableView];
}

#pragma mark -------------底部button ---------------
-(void)setBottomBtn
{
    _bottomBtnView = [[IndexBottomView alloc]initWithFrame:CGRectMake(0, SCREENHEIGHT - 54, SCREENWIDTH, 54)];
    [self.view addSubview:_bottomBtnView];
    //跳转到栏目页面
    __weak typeof(self) weakSelf = self;
    _bottomBtnView.columnBtnBlock = ^(IndexBottomView *indexBtnBlock) {
        [weakSelf.navigationController popViewControllerAnimated:YES];
    };
    //跳转到设置页面
    _bottomBtnView.setBtnBlock = ^(IndexBottomView *indexBtnBlock) {
        [weakSelf.navigationController pushViewController:[[SetViewController alloc] init] animated:YES];
    };
}

#pragma mark ------------- Table view data source ---------------

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    _cell = [tableView dequeueReusableCellWithIdentifier:@"MyDiaryTableViewCell"];
    _cell.backgroundColor = [UIColor clearColor];
    [_cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    NSString *filePath = [NSString stringWithFormat:@"%@/Library/Caches/%@/diaryPhoto/diary%ld.jpg", NSHomeDirectory(), gainDefault(@"userName"), indexPath.row];
    [_cell.mainImgView setImage:[UIImage imageWithContentsOfFile:filePath]];
    _model = [[Diary alloc] init];
    
    _model = self.tableViewDataArr[indexPath.row];
    
    [_cell setModel:_model];
    
    __weak typeof(self) weakSelf = self;
    _cell.jumpSharePage = ^(UITableViewCell *indexViewBlock) {
        [weakSelf.navigationController pushViewController:[[ShareViewController alloc] init] animated:YES];
    };
    
    return _cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableViewDataArr.count;
}

#pragma mark -------------UITableViewDelegate----------------
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 130;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DiaryDetailViewController *diaryVC = [[DiaryDetailViewController alloc] init];
    diaryVC.titleLab.text = [self.tableViewDataArr[indexPath.row] valueForKey:@"NAME_CN"];
    if([gainDefault(@"charType") isEqualToString:@"english"])
        diaryVC.titleLab.text = [self.tableViewDataArr[indexPath.row] valueForKey:@"NAME_EN"];
    [self.navigationController pushViewController:diaryVC animated:YES];
}
@end
