//
//  DiaryTableViewController.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiaryTableViewController : PublicViewController

@property (nonatomic,strong) UILabel *userNameLab;

@end
