//
//  DiaryDetailViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "DiaryDetailViewController.h"
#import <WebKit/WebKit.h>
@interface DiaryDetailViewController ()<WKNavigationDelegate>
{
    UIView *backView;
    UIImageView *imgView;
    NSInteger realScreenWidth;
    NSInteger realScreenHeight;
}
@property (nonatomic,strong) UIScrollView *scrollView;

@property (nonatomic,strong) WKWebView *wkWebview;

@end

@implementation DiaryDetailViewController
-(UILabel *)titleLab
{
    if(!_titleLab)
    {
        _titleLab = [[UILabel alloc] init];
    }
    return _titleLab;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
   //显示用户名
    [self setHeaderTitle:YES];
    //返回按钮
    [self setTabbar:YES andClose:NO];

    //初始化日志详情
    [self initDiaryDetailView];
}
//初始化日志详情
-(void)initDiaryDetailView
{
    //加载wkWebview
    _wkWebview = [[WKWebView alloc] initWithFrame:CGRectMake(0, 50, SCREENWIDTH, self.view.frame.size.height - 120)];
    
    _wkWebview.scrollView.showsHorizontalScrollIndicator = NO;
    _wkWebview.scrollView.showsVerticalScrollIndicator = NO;
    _wkWebview.navigationDelegate = self;
    [self.view addSubview:_wkWebview];
    
    //根据传过来的标题文字 找对应的数据库资源
    NSDictionary *dic;
    dic = @{@"NAME_CN":self.titleLab.text};
    if([gainDefault(@"charType") isEqualToString:@"english"])
    {
        dic = @{@"NAME_EN":self.titleLab.text};
    }
    NSArray * dataArr =  [[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"Diary" andDicitonary:dic];
    
    //转换内容文本的h5格式
    NSString *str = [dataArr[0] valueForKey:@"CONTENT_CN"];
    NSLog(@"%@", str);
    CGFloat width = [UIScreen mainScreen].bounds.size.width - 20;
    CGFloat fontSize = 18;
    
    NSMutableString *contentStr = [NSMutableString stringWithFormat:@"<html>\
                                   <head>\
                                   <title></title>\
                                   <meta name=\"viewport\" content=\"width=device-width, minimum-scale=1.0, initial-scale=1.0, maximum-scale=1.0, user-scalable=1\" />\
                                   </head>\
                                   <style>\
                                   img {\
                                   display:table-cell;\
                                   text-align:center;\
                                   vertical-align:middle;\
                                   max-width:%fpx;\
                                   width:expression(this.width<%fpx?\"auto\":\"%fpx\");\
                                   max-height:auto;\
                                   margin:auto;\
                                   }</style>\
                                   <body width=\"%fpx\" style=\"\"><h3>%@</h3><p>%@</p><br/><div class=\"header\" style=\"word-break : break-all;overflow:hidden;width: %fpx;font-size:%fpx\">%@</div></body></html>", width, width, width, width, self.titleLab.text, [dataArr[0] valueForKey:@"SUBMIT_DATE"], width, fontSize, str];
    //替换img字段
    [contentStr replaceOccurrencesOfString:@"<img" withString:@"<img onclick =\"imgClicked(this)\"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [contentStr length])];
    
    [_wkWebview loadHTMLString:contentStr baseURL:nil];
}

#pragma mark--------------WKNavigationDelegate------------------

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [webView evaluateJavaScript:@"function imgClicked(element){\
     document.location = element.src;\
     }" completionHandler:^(id par , NSError *error)
     {
         //NSLog(@"%@",error);
         ;
     }];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
//    NSString *str = [navigationAction.request.mainDocumentURL pathExtension];
    NSString *str = [[navigationAction.request URL] absoluteString];
//    NSLog(@"%@", str);
    /*hasSuffix（string）返回一个布尔值表示字符串是否以指定的后缀结束。
     如果一直返回true 如果不一致返回false
     hasPrefix（string）返回一个布尔值表示字符串是否以指定的前缀开始。*/
    if ([str hasPrefix:@"http://"])
    {
        [self showImgView:str];
        
        decisionHandler(WKNavigationActionPolicyCancel);
        return;//必须要写 不写会崩。
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)showImgView:(NSString *)url
{
    backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT)];
    backView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:1];
    
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 100, SCREENWIDTH - 20, SCREENHEIGHT - 200)];
    imgView.userInteractionEnabled = YES;
    //添加点击手势
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoDisappear)];
    [imgView addGestureRecognizer:tap];
    
    NSData *imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    imgView.image = [UIImage imageWithData:imgData];
    imgView.contentMode = UIViewContentModeScaleAspectFit;
    [backView addSubview:imgView];
    [self.view addSubview:backView];
}

-(void)photoDisappear
{
    backView.hidden = YES;
}

//屏幕旋转走的方法
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    NSLog(@"size.width = %lf,size.height = %lf", size.width, size.height);
    realScreenWidth = size.width;
    realScreenHeight = size.height;
    
    [self viewReversal];
}

-(void)viewReversal
{
    //修改view的frame
    backView.frame = CGRectMake(0, 0, realScreenWidth, realScreenHeight);
    imgView.frame = CGRectMake(10, 100, realScreenWidth - 20, realScreenHeight - 200);
}

@end
