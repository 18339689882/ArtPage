//
//  PrivateInsertView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/10.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrivateInsertView : UIView

@property (nonatomic,strong) UILabel *privateTextLab;
@property (nonatomic,strong) UITextField *privatePwdTextField;
@property (nonatomic,strong) UIImageView *lineView;
@property (nonatomic,strong) UIButton *interPrivateBtn;

typedef void(^jumpBLock)(PrivateInsertView *block);
@property (nonatomic, copy)jumpBLock block;

@end
