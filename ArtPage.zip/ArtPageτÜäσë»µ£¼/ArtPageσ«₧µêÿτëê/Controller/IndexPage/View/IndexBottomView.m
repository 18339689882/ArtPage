//
//  IndexBottomView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "IndexBottomView.h"

@implementation IndexBottomView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        _columnBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_columnBtn setImage:[UIImage imageNamed:@"btn_栏目"] forState:UIControlStateNormal];
        [_columnBtn addTarget:self action:@selector(interColumnPage) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_columnBtn];
        [_columnBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.centerY);
            make.left.equalTo(98);
            make.height.width.equalTo(50);
        }];
        
        _setBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_setBtn setImage:[UIImage imageNamed:@"btn_设置"] forState:UIControlStateNormal];
        [_setBtn addTarget:self action:@selector(interSetPage) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_setBtn];
        [_setBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.centerY);
            make.right.equalTo(-98);
            make.height.width.equalTo(50);
        }];
    }
    return self;
}
-(void)interColumnPage
{
    if(_columnBtnBlock)
    {
        _columnBtnBlock(self);
    }
}
-(void)interSetPage
{
    if(_setBtnBlock)
    {
        _setBtnBlock(self);
    }
}
@end
