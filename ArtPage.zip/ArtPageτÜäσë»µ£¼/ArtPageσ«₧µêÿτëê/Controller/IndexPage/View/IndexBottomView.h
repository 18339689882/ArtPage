//
//  IndexBottomView.h
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/9/30.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndexBottomView : UIView

@property (nonatomic, strong)UIButton *columnBtn;
@property (nonatomic, strong)UIButton *setBtn;
//页面跳转Block
typedef void(^interColumn)(IndexBottomView *indexBtnBlock);
@property (nonatomic, copy)interColumn columnBtnBlock;

typedef void(^interSet)(IndexBottomView *indexBtnBlock);
@property (nonatomic, copy)interSet setBtnBlock;

@end
