//
//  PrivateInsertView.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/10.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "PrivateInsertView.h"

@implementation PrivateInsertView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UIView *backView = [[UIView alloc] init];
        backView.backgroundColor = [UIColor blackColor];
        [self addSubview:backView];
        [backView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(184);
            make.left.equalTo(0);
            make.width.equalTo(SCREENWIDTH);
            make.height.equalTo(200);
        }];
        //非公开作品分组名称
        _privateTextLab = [[UILabel alloc] init];
        _privateTextLab.textAlignment = NSTextAlignmentCenter;
        _privateTextLab.font = [UIFont systemFontOfSize:18];
        _privateTextLab.textColor = WSColorFromRGB(0xa0a0a0);
        [_privateTextLab setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18]];
        [backView addSubview:_privateTextLab];
        [_privateTextLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(10);
            make.centerX.equalTo(self.centerX);
            make.width.equalTo(SCREENWIDTH);
            make.height.equalTo(20);
        }];
        
        //请输入分组密码
        _privatePwdTextField = [[UITextField alloc] init];
        _privatePwdTextField.textAlignment = NSTextAlignmentLeft;
        _privatePwdTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"请输入分组密码" attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor grayColor], NSForegroundColorAttributeName, nil]];
        _privatePwdTextField.textColor = [UIColor whiteColor];
        _privatePwdTextField.font = [UIFont systemFontOfSize:14];
        [backView addSubview:_privatePwdTextField];
        [_privatePwdTextField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.privateTextLab.bottom).offset(36);
            make.left.equalTo(48);
            make.height.equalTo(16);
            make.width.equalTo(SCREENWIDTH);
        }];
        //线
        _lineView = [[UIImageView alloc] init];
        _lineView.backgroundColor = [UIColor grayColor];
        [backView addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.privatePwdTextField.bottom).offset(7);
            make.left.equalTo(45);
            make.width.equalTo(SCREENWIDTH - 90);
            make.height.equalTo(0.5);
        }];
        //进入分组btn
        _interPrivateBtn = [[UIButton alloc] init];
        [_interPrivateBtn setTitle:@"进入分组" forState:UIControlStateNormal];
        [_interPrivateBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        _interPrivateBtn.backgroundColor = [UIColor blackColor];
        _interPrivateBtn.layer.masksToBounds = YES;
        _interPrivateBtn.layer.cornerRadius = 6.0;
        _interPrivateBtn.layer.borderWidth = 1.5;
        _interPrivateBtn.layer.borderColor = [[UIColor grayColor] CGColor];
        [_interPrivateBtn addTarget:self action:@selector(pressInterBtn) forControlEvents:UIControlEventTouchUpInside];
        [backView addSubview:_interPrivateBtn];
        [_interPrivateBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.lineView.bottom).offset(10);
            make.centerX.equalTo(self.centerX);
            make.width.equalTo(SCREENWIDTH - 100);
            make.height.equalTo(60);
        }];
    }
    return self;
}
-(void)pressInterBtn
{
    [self.privatePwdTextField resignFirstResponder];
    if(_block)
    {
        _block(self);
    }
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self endEditing:YES];
}
@end
