//
//  IndexTableViewController.m
//  ArtPage实战版
//
//  Created by Sunweisheng on 2018/10/9.
//  Copyright © 2018年 Sunweisheng. All rights reserved.
//

#import "IndexTableViewController.h"
#import "IndexBottomView.h"
#import "SetViewController.h"
#import "IndexTableViewCell.h"
#import "PhotocollectionViewController.h"
#import "ShareViewController.h"
#import "PublicGroup.h"
#import "ColumnViewController.h"
#import "PrivateInsertView.h"
#import "AppDelegate.h"
@interface IndexTableViewController ()<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>

@property (nonatomic,strong) UILabel *userNameLab;
@property (nonatomic,strong) IndexBottomView *bottomBtnView;

@property (nonatomic,strong) UITableView *aTableView;

//数据源
@property (nonatomic,strong) NSMutableArray *tableViewDataArr;

@property (nonatomic,strong) IndexTableViewCell *cell;

@property (nonatomic,strong) PublicGroup *model;

@property (nonatomic,strong) PrivateInsertView *privateInsterView;
@end

@implementation IndexTableViewController

//懒加载tableViewDataArr
-(NSMutableArray *)tableViewDataArr
{
    _tableViewDataArr = [NSMutableArray arrayWithCapacity:1];
        //公开分组
    _tableViewDataArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"PublicGroup"];
    if([gainDefault(@"groupType") isEqualToString:@"private"])
    {
        //私密分组
        _tableViewDataArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"PrivateGroup"];
    }
    return _tableViewDataArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //显示用户名
    [self setHeaderTitle:YES];
    //设置底部按钮
    [self setBottomBtn];
    //初始化tableView
    [self initTableView];
}

//初始化tableView
-(void)initTableView
{
    _aTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 60, SCREENWIDTH, SCREENHEIGHT - 120) style:UITableViewStylePlain];
    //注册cell
    [_aTableView registerClass:[IndexTableViewCell class] forCellReuseIdentifier:@"IndexTableViewCell"];
    _aTableView.backgroundColor = [UIColor blackColor];
    //遵循代理
    _aTableView.delegate = self;
    _aTableView.dataSource = self;
    
    [self.view addSubview:_aTableView];
}

-(void)setBottomBtn
{
    _bottomBtnView = [[IndexBottomView alloc]initWithFrame:CGRectMake(0, SCREENHEIGHT - 54, SCREENWIDTH, 54)];
    [self.view addSubview:_bottomBtnView];
    //跳转到栏目页面
    __weak typeof(self) weakSelf = self;
    _bottomBtnView.columnBtnBlock = ^(IndexBottomView *indexBtnBlock) {
        [weakSelf.navigationController pushViewController:[[ColumnViewController alloc] init] animated:YES];
    };
    //跳转到设置页面
    _bottomBtnView.setBtnBlock = ^(IndexBottomView *indexBtnBlock) {
        [weakSelf.navigationController pushViewController:[[SetViewController alloc] init] animated:YES];
    };
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark ------------- Table view data source ---------------

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    _cell = [tableView dequeueReusableCellWithIdentifier:@"IndexTableViewCell"];
    _cell.backgroundColor = [UIColor clearColor];
    
    //把公开分组和非公开分组 弄成一个数组
    NSMutableArray *dataArr = [NSMutableArray arrayWithCapacity:1];
    dataArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"PublicGroup"];
    NSArray *privatArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"PrivateGroup"];
    [dataArr addObjectsFromArray:privatArr];
    //找到GroupID
    NSArray *dataArr1 = [dataArr valueForKey:@"GroupID"];
    
    NSDictionary *dic = @{@"GroupID":dataArr1[indexPath.row]};
    NSArray *dataNumArr = [[GetDataBase shareDataBase] wzGetRecorderDataForTwoWithTableName:@"GroupIDFindArtID" andDicitonary:dic];
    _cell.numLab.text = [NSString stringWithFormat:@"%ld个项目",dataNumArr.count];
    [_cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    //这里应该加载groupImg
    NSString *filePath = [NSString stringWithFormat:@"%@/Library/Caches/%@/diaryPhoto/diary%ld.jpg", NSHomeDirectory(), gainDefault(@"userName"), indexPath.row];
    [_cell.mainImgView setImage:[UIImage imageWithContentsOfFile:filePath]];
    
    _model = [[PublicGroup alloc] init];
    _model = self.tableViewDataArr[indexPath.row];
    [_cell setModel:_model];
    
    __weak typeof(self) weakSelf = self;
    _cell.jumpSharePage = ^(UITableViewCell *indexViewBlock) {
        [weakSelf.navigationController pushViewController:[[ShareViewController alloc] init] animated:YES];
    };
    return _cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableViewDataArr.count;
}

#pragma mark -------------UITableViewDelegate----------------
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoCollocationViewController *photoVC = [[PhotoCollocationViewController alloc] init];
    NSLog(@"charType = %@", gainDefault(@"charType"));
    //中英文切换
        photoVC.titleLab.text = [self.tableViewDataArr[indexPath.row] valueForKey:@"GroupName_CN"];
    if ([gainDefault(@"charType") isEqualToString:@"english"])
        photoVC.titleLab.text = [self.tableViewDataArr[indexPath.row] valueForKey:@"GroupName_EN"];
    
    photoVC.groupID = [self.tableViewDataArr[indexPath.row] valueForKey:@"GroupID"];
    //    NSLog(@"%@", photoVC.groupID);
    
    //得到私密分组的数量
    NSArray *privateArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"PrivateGroup"];
    for(int i = 0; i < privateArr.count; ++i)
    {
//        NSLog(@"self.model.groupID = %@", [self.tableViewDataArr[indexPath.row] valueForKey:@"GroupID"]);
//        NSLog(@"%@", [privateArr[i] valueForKey:@"GroupID"]);
        //判断所点击的分组是否是加密分组
        if([[self.tableViewDataArr[indexPath.row] valueForKey:@"GroupID"] isEqual:[privateArr[i] valueForKey:@"GroupID"]])
        {
            //加载弹出视图
            _privateInsterView = [[PrivateInsertView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT)];
            
            //中英文切换
            _privateInsterView.privateTextLab.text = [NSString stringWithFormat:@"%@", [self.tableViewDataArr[indexPath.row] valueForKey:@"GroupName_CN"]];
            if ([gainDefault(@"charType") isEqualToString:@"english"])
                _privateInsterView.privateTextLab.text = [NSString stringWithFormat:@"%@", [self.tableViewDataArr[indexPath.row] valueForKey:@"GroupName_EN"]];
            
            _privateInsterView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
            [self.view addSubview:_privateInsterView];
            NSString *privateGroupPwd = [self.tableViewDataArr[indexPath.row] valueForKey:@"Password"];
            //获得对应分组的密码
            NSLog(@"%@",privateGroupPwd);
            __weak typeof(self) weakSelf = self;
            _privateInsterView.block = ^(PrivateInsertView *block) {
                //判断密码是否相同
                if([weakSelf.privateInsterView.privatePwdTextField.text isEqualToString:privateGroupPwd])
                {
                    if(![weakSelf.navigationController.topViewController isKindOfClass:[photoVC class]]) {
                        [weakSelf.navigationController pushViewController:photoVC animated:YES];
                    }else
                    {
                        NSLog(@"此处可能会报错");
                    }
                }
                else
                {
                    [weakSelf showAlertView:@"密码输入错误" andMessage:@"确定"];
                }
            };
        }
    }
    //得到公开分组的个数
    NSArray *publicGroupArr = [[GetDataBase shareDataBase] wzGainTableRecoderID:@"PublicGroup"];
    for(int i = 0; i < publicGroupArr.count; ++i)
    {
        if([[self.tableViewDataArr[indexPath.row] valueForKey:@"GroupID"] isEqual:[publicGroupArr[i] valueForKey:@"GroupID"]])
        {
            if(![self.navigationController.topViewController isKindOfClass:[photoVC class]]) {
                [self.navigationController pushViewController:photoVC animated:YES];
            }else
            {
                NSLog(@"此处可能会报错");
            }
        }
    }
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //禁用右滑返回
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //恢复右滑返回
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
}
- (void)viewWillAppear:(BOOL)animated
{
    self.privateInsterView.hidden = YES;
    [self.aTableView reloadData];
}

@end
